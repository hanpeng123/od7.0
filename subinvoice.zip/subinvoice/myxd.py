from openerp.osv import osv,fields


class Myxd(osv.TransientModel):
    
    _name='test.my.xd'
    _columns={
              'code':fields.char(size=10,required=True,string=u"Code"),
              'name':fields.char(size=10,required=False,string=u"Name"),
              }
    
    def create(self,cr,uid,vals,context=None):
        obj=self.pool.get('test.parent.window')
        obj.create(cr,uid,{'code':vals['code'],'name':vals['name']},context=context)
        return super(Myxd,self).create(cr,uid,vals,context=context)
Myxd()