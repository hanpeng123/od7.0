# -*- coding:utf-8 -*-
from openerp.osv import osv,fields

class TestField(osv.Model):
    
    def _get_status(self,cr,uid,ids,fields,args,context=None):
        return True
    
    _name='test.field'
    _columns={
              'code':fields.char(size=100,required=True,string=u"Code"),
              'name':fields.char(size=100,required=True,string=u"Name",invisible=False,states={'open':[('invisible',True)]}),
              'myvalue':fields.float(u"Amount"),
              'state':fields.selection([('open','Open'),('audit','Audit'),('close','Closed')],u"Status",required=True,invisible=True),
              'isactive':fields.boolean(u"Active"),
              'isact':fields.function(_get_status,type='boolean',string=u"Is Act(Function)"),
              'acc_code':fields.selection([('1001','1001 Cash'),('1002',u"1002 bank")],u"Account Code"),
              }
    _defaults={
              'state':'open',
              'isactive':True,
              }
    
    def onchange_state(self,cr,uid,ids,acc_code,context=None):
        print "======="
        print "i am here."
        if not acc_code:
            return {'value':{'state':'open'}}
        return {'value':{'state':'audit'}}
TestField()