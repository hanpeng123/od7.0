{
    'name' : 'EasyBook accounting software',
    'version' : '1.0',
    'author' : 'hanpeng',
    'category' : 'accounting',
    'description' : """
    This software is designed for small entities.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['base'],
    'data': [
             'views/book_entity_view.xml',
             "views/book_accounting_period_view.xml",
             'views/book_accounts_view.xml',
             'views/book_closeaccount_view.xml',
             
             'views/menus.xml',
             #'db/business.sql',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
