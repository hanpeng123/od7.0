{
    'name' : 'EasyBook Accounting Software',
    'version' : '1.0',
    'author' : 'hanpeng',
    'category' : 'accounting',
    'description' : """
    This software is designed for small entities.
    """,
    'website': 'http://www.openerp.com',
    'images' : ['images/abacus.png',],
    'depends' : ['base'],
    'data': [
             'views/book_entity_view.xml',
             "views/book_accounting_period_view.xml",
             'views/book_accounts_view.xml',
             'views/book_closeaccount_view.xml',
             'views/book_voucher_view.xml',
             'views/book_period_view.xml',
             
             'views/menus.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
