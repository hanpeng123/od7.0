drop function if exists easy_get_lastday(date_convers date);
create or replace function easy_get_lastday(date_convers date)
returns timestamp with time zone
AS
$$
select (date_trunc('MONTH', date_convers) + INTERVAL '1 MONTH - 1 day'); 
$$
language SQL
returns null on null input;