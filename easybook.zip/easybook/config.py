from openerp.osv import osv, fields


class AccountsConfig(osv.Model):
    _name = 'easy.base.config.settings'
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity", domain=[('default_entity', '=', True) ], ondelete='cascade'),
              'force_voucher_seq':fields.boolean(u'Force Vouchers No. sequential when a period is closed'),
              }
    
    _defaults = {
               'force_voucher_seq':False,
               }
    
    def view_init(self, cr, uid, fields_list, context=None):
        print "))))))))))((((((((((("
    
    def name_get(self, cr, uid, ids, context=None):
        if not ids:
            return []
        if isinstance(ids, (int, long)):
                    ids = [ids]
        res = []
        for i in ids:
            res.append((i, 'General Settings'))
        return res

AccountsConfig()
