from openerp.osv import osv, fields
from openerp import tools

class ViewAccounts(osv.TransientModel):
    
    _name = 'easy.view.accounts'
    _columns = {
              #'start_date':fields.many2one('easy.period.line', u"Start Date", ondelete='cascade', domain=[('is_current', '=', True)]),
              #'end_date':fields.many2one('easy.period.line', u"End Date", ondelete='cascade', domain=[('is_current', '=', True)]),
              'start_date':fields.date(u'Start Date',required=True),
              'end_date':fields.date(u'End Date',required=True),
              'voucher_status':fields.selection([('make',u'Making'),('approve',u'Approved'),('book',u'Posted'),('all',u'All Status')],string=u"Voucher Status"),
              'accounts':fields.many2many('easy.accounts', 'easy_accounts_view_rel', 'view_account_id', 'account_id', u"Accounts", ondelete='cascade', domain=[('is_default_entity', '=', True)]),
              'descr':fields.text(u"Attention", readonly=True),
              }
    _defaults = {
               'descr':"""
1,You may select accounts you want to view,single or multi.\n   If you do not select any account,it considers all accounts you want to view.\n
2,Accounting periods are in current fiscal year.\n
3,If voucher status is not selected,it is regarded as all status.
               """,
               'voucher_status':'all',
               }
    def open_accounts_detail(self, cr, uid, ids, context=None):
        #
        obj=self.browse(cr,uid,ids[0],context)
        #
        acc_ids=[]
        acc_obj=obj.accounts
        status=obj.voucher_status
        if status=='all' or not status:
            status="'make','approve','book'"
        else:
            status="'"+status+"',"
        if acc_obj:
            for line in acc_obj:
                acc_ids.append(line.id)
            acc_ids=str(acc_ids)
            acc_ids=acc_ids.replace('[', '')
            acc_ids=acc_ids.replace(']', '')
            sql_str="""
            with recursive info(acc_id,acc_name,p_id) as (
                select id acc_id,name acc_name,parent_id pid from easy_accounts where id in (%s)
                union all
                select id,name,parent_id from easy_accounts acct inner join info on acct.parent_id=info.acc_id
                )
                select acc_id from info;
            """%(acc_ids,)
            cr.execute(sql_str)
            res=cr.dictfetchall()
            acc_ids=[]
            if res:
                for line in res:
                    acc_ids.append(line['acc_id'])
            acc_ids=str(acc_ids)
            acc_ids=acc_ids.replace('[', '')
            acc_ids=acc_ids.replace(']', '')  
        domain_con="[('voucher_date','>=','%s'),('voucher_date','<=','%s'),('status','in',(%s))]"%(obj.start_date,obj.end_date,status)
        if acc_ids:
            domain_con="[('voucher_date','>=','%s'),('voucher_date','<=','%s'),('acc_id','in',(%s)),('status','in',(%s))]"%(obj.start_date,obj.end_date,acc_ids+',',status)
        #
        ir_model_data=self.pool.get('ir.model.data')
        compose_form_id=ir_model_data.get_object_reference(cr,uid,'easybook','viewaccountsdetail_tree_view')[1]
        ctx=dict(context)
        ctx.update({
                   'default_voucher_date':obj.start_date,
                   })
        return {
                'name':'Accounts Details',
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'tree',
                'res_model': 'easy.accounts.balance',
                'views': [(compose_form_id, 'tree')],
                'view_id': compose_form_id,
                'nodestroy': True,
                'context': ctx,
                'domain':domain_con
                #'target':'new',
                }
    
ViewAccounts()

class AccountsBalance(osv.Model):
    _name="easy.accounts.balance"
    _auto=False
    _columns={
              'voucher_date':fields.date(u"Voucher Date"),
              'code':fields.integer(u"Voucher Code"),
              'acc_code':fields.char(size=100,string=u"Account Code"),
              'acc_name':fields.char(size=120,string=u"Account Name"),
              'acc_id':fields.integer(u"Acc IDs"),
              'descr':fields.char(size=200,string=u"Description"),
              'debit_amount':fields.float(string=u"Debit Amount",digits=(12,2)),
              'credit_amount':fields.float(string=u"Credit Amount",digits=(12,2)),
              'status':fields.char(size=20,string=u'Status'),
              }
    
    def init(self,cr):
        tools.sql.drop_view_if_exists(cr, 'easy_accounts_balance')
        cr.execute("""
        create or replace view easy_accounts_balance as
        select line.id,vou.voucher_date,coalesce(vou.code1,vou.code) code,acc.code acc_code,acc.name acc_name,acc.id acc_id,
        line.description descr,line.debit_amount,line.credit_amount,
        vou.state status
        from easy_voucher vou
        inner join easy_voucher_line line on vou.id=line.voucher_id
        inner join easy_accounts acc on line.account_id=acc.id
        where vou.is_default_entity=True
        """)

AccountsBalance()

class ViewAccountsBalance(osv.TransientModel):
    
    def _get_default_period(self,cr,uid,ids,context=None):
        sql_str="""
        select min(id) mid from easy_period_line where isactive=True and is_current=True;
        """
        cr.execute(sql_str)
        res=cr.dictfetchone()
        if res:
            return res['mid']
        return None
    
    _name='easy.view.acconts.balance.period'
    _columns={
             'period_line_id':fields.many2one('easy.period.line',u"Period",domain=[('is_current','=',True),]),
             #'descrip':fields.text(u"Attention",readonly=True),
             }
    _defaults={
               'period_line_id':_get_default_period,
               }
    def open_accounts_balance(self, cr, uid, ids, context=None):
        #
        
        obj=self.browse(cr, uid, ids[0],context)
        line_id=obj.period_line_id if obj else 0
        domain_con="[('period_line_id','=',%d),]"%(line_id,)
        print ")))))))))))))))))))))"
        print domain_con
        ir_model_data=self.pool.get('ir.model.data')
        compose_form_id=ir_model_data.get_object_reference(cr,uid,'easybook','balanceshown_tree_view')[1]
        ctx=dict(context if context else {})
        ctx.update({'search_default_group_by_root_account':1})
        return {
                'name':'Accounts Balance',
                'type': 'ir.actions.act_window',
                'view_type': 'form',
                'view_mode': 'tree,graph',
                'res_model': 'easy.accounts.balance.shown',
                'views': [(compose_form_id, 'tree')],
                'view_id': compose_form_id,
                'nodestroy': True,
                'context':ctx,
                'domain':domain_con,
                #'target':'new',
                }
    
ViewAccountsBalance()

class AccountsBalanceShown(osv.Model):
    _name = 'easy.accounts.balance.shown'
    _auto = False
    _columns = {
              'period_line_id':fields.integer(u"Period Line ID"),
              'acc_id':fields.integer(u"Account ID"),
              'accounts':fields.char(size=120, string=u"Account Name"),
              'init':fields.float(u"Init Balance", digits=(12, 2)),
              'debit':fields.float(u"Debit Amount", digits=(12, 2)),
              'credit':fields.float(u"Credit Amount", digits=(12, 2)),
              'blc':fields.float(u"Balance", digits=(12, 2)),
              'root_id':fields.char(size=240,string=u"Root Account"),
              'acc_type':fields.char(size=10,string=u"Accounts Type"),
              'acc_direction':fields.char(size=100,string=u"Account Direction"),
              }
    _sql="""
        drop SEQUENCE if exists easy_balance_view_sq cascade;
        create sequence easy_balance_view_sq
        start with 1
        INCREMENT by 1
        CYCLE
        no MAXVALUE
        minvalue 1;    
        
        drop view if exists easy_accounts_view2;
        create or replace view easy_accounts_view2 
        as
        with recursive info(acc_id,pid,acc_code,acc_name,root_code,root_id,lv) as (
        select id acc_id,parent_id pid,code acc_code,show_name acc_name,code root_code,id root_id,1 lv 
        from easy_accounts where is_default_entity=True and parent_id is null
        union all
        select id,parent_id,code,show_name,info.root_code,info.root_id,info.lv+1 
        from easy_accounts acct 
        inner join info on acct.parent_id=info.acc_id
        where acct.is_default_entity=True
        )
        select acc_id id,acc_code,acc_name,root_code,root_id,lv from info
        order by root_code,acc_code;
    """
    
    def init(self, cr):
        tools.sql.drop_view_if_exists(cr, 'easy_accounts_balance_shown')
        cr.execute("""
        create or replace view easy_accounts_balance_shown
        as
        select bc.id,bc.period_line_id,bc.account_id acc_id,acc.acc_code||' '||acc.acc_name accounts,bc.init_amount init,bc.debit_amount debit,
        bc.credit_amount credit,bc.balance blc, ac.name root_id,ac.classification acc_type,ac.direction acc_direction
        from easy_accounts_balance_close bc
        inner join easy_accounts_view2 acc on bc.account_id=acc.id
        inner join easy_accounts ac on acc.root_id=ac.id
        """)
        
AccountsBalanceShown()