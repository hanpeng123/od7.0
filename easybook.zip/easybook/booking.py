# -*- coding:utf-8 -*-
from openerp.osv import osv, fields
import time
import datetime
from openerp import tools
from openerp.tools.translate import _
from openerp.osv.osv import except_osv

class AccTools():
    
    # 这个函数是将字符串日期转换成DATE类型，此处要评估时间的字符串格式是否为年-月-日格式，才能在生产环境发布
    def get_date_from_string(self, datestring):
        date_info = time.strptime(datestring, "%Y-%m-%d")
        y = date_info[0]
        m = date_info[1]
        d = date_info[2]
        return datetime.date(y, m, d)
    
    def date_addamonth(self, dt):
        y = dt.year
        m = dt.month + 1
        if m > 12:
            y += 1
            m = 1
        return datetime.date(y, m, 1)
    
    def days_of_month(self, year, month):
        dayslist = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
            dayslist[1] = 29
        return datetime.date(year, month, dayslist[month - 1])
    
    def months_period(self, d_start, d_end):
        res = []
        i = 0
        while(d_start <= d_end):
            first_day = d_start
            last_day = self.days_of_month(d_start.year, d_start.month)
            if last_day > d_end:
                last_day = d_end
            curr = (first_day, last_day)
            res.append(curr)
            d_start = self.date_addamonth(d_start)
        return res
    
    def get_current_year_day(self, symble):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        # #
        if symble == 0:
            ticks = str(ticks) + '-01' + '-01'
        elif symble == 1:
            ticks = str(ticks) + '-12' + '-31'
        return ticks
    
    def get_current_year(self):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        return ticks
    
    def get_current_datetime(self):
        ticks = time.localtime(time.time())
        return str(ticks[0]) + '-' + str(ticks[1]) + '-' + str(ticks[2]) + ' ' + str(ticks[3]) + ':' + str(ticks[4]) + ':' + str(ticks[5])


class AccountEntity(osv.Model):
    
    actools = AccTools()
    
    _first_day_of_year = actools.get_current_year_day(0)
    _last_day_of_year = actools.get_current_year_day(1)
    
    def _get_default_current_datetime(self, cr, uid, ids, context=None):
        actools = AccTools()
        return actools.get_current_datetime()
    
    def _get_default_current_date(self, cr, uid, ids, context=None):
        DATETIME_FORMAT = "%Y-%m-%d"
        ticks = time.localtime(time.time())
        current_date = str(ticks[0]) + '-' + str(ticks[1]).rjust(2, '0') + '-' + str(ticks[2]).rjust(2, '0')
        return current_date
    
    def onchange_bookdate(self, cr, uid, ids, bookdate, context=None):
        DATETIME_FORMAT = "%Y-%m-%d"
        bookdate = datetime.datetime.strptime(bookdate, DATETIME_FORMAT)
        year_start = str(bookdate.year) + '-01-01'
        year_end = str(bookdate.year) + '-12-31'
        val = {'year_start':year_start, 'year_end':year_end}
        return {'value':val}
    
    def _check_bookdate_period(self, cr, uid, ids, context=None):
        #
        DATETIME_FORMAT = "%Y-%m-%d"
        obj = self.browse(cr, uid, ids[0], context)
        bookdate = obj.date_start_book
        p_sdate = obj.year_start
        p_edate = obj.year_end
        if not(bookdate >= p_sdate and bookdate <= p_edate):
            return False
        return True
    
    
    _name = 'easy.entity'
    _columns = {
              'code':fields.char(size=20, required=True, string=u"Entity Code"),
              'name':fields.char(size=100, required=True, string=u"Entity Name"),
              'period_ids':fields.one2many('easy.period', 'entity_id', u"Period IDs"),
              'config_ids':fields.one2many('easy.base.config.settings', 'entity_id', u"Config Setting"),
              'accounts_ids':fields.one2many('easy.accounts', 'entity_id', u"Accounts", readonly=True),
              'acc_patten_ids':fields.one2many('easy.account.patten', 'entity_id', u"Accounts Patten IDs"),
              'year_start':fields.date(required=True, string=u"Financial Year Start", readonly=False, states={'open': [('readonly', True)]}),
              # 'year_start':fields.date(required=True, string=u"Financial Year Start", readonly=True),
              'year_end':fields.date(required=True, string=u"Financial Year End", readonly=False, states={'open': [('readonly', True)]}),
              # 'year_end':fields.date(required=True, string=u"Financial Year End", readonly=True),
              'date_start_book':fields.date(string=u"Booking Date", required=True, readonly=False, states={'open': [('readonly', True)], 'closed':[('readonly', True)]}),
              'vat_scale':fields.selection([('small', u"Small"), ('general', u"General"), ], string=u"Entity Type", required=True, readonly=False, states={'open': [('readonly', True)]}),
              'isactive':fields.boolean(u"Active"),
              'remark':fields.text(u"Remark"),
              'state': fields.selection([('edit', 'Editing'), ('open', 'Open'), ('closed', 'Closed'), ], 'Status', readonly=True),
              'default_entity':fields.boolean(u"Default Entity", readonly=True),
              'close_init':fields.boolean(u"Close Initial", readonly=True),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
              'isactive':True,
              'year_start':_first_day_of_year,
              'year_end':_last_day_of_year,
              'date_start_book':_get_default_current_date,
              'vat_scale':'small',
              'state':'edit',
              'default_entity':True,
              'ts':_get_default_current_datetime,
              'close_init':False,
              }
    _sql_constraints = [
                      ('unique_entity_code', 'unique(code)', 'Entity code must be unique!'),
                      ('unique_entity_name', 'unique(name)', 'Entity name must be unique!'),
                      ('start_gt_end', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ]
    
    _constraints = [
                  (_check_bookdate_period, 'Book date must between year start date \nand year end date!', ['Date Error!'])
                  ]
    
    def create(self, cr, uid, vals, context=None):
        # Only permit to create one entity
        sql_str = """
        select count(id) ct from easy_entity;
        """
        cr.execute(sql_str)
        ent = cr.dictfetchone()
        if ent['ct'] > 0:
            raise osv.except_osv(_('Refuse!'), _('You only permit to create one accounting entity!'))
        # create configure data:[[0, False, {'year_start': '2014-01-01', 'year_end': '2014-12-31'}]]
        if vals['year_start'] and vals['year_end']:
            res = []
            configsetting = []
            configsetting.append(0)
            configsetting.append(False)
            configsetting.append({'force_voucher_seq':False})
            res.append(configsetting)
            vals['config_ids'] = res
        # 修改会计主体的状态
        vals['state'] = 'open'
        # 向会计期间主表写入数据
        if vals['year_start'] and vals['year_end']:
            res = []
            periods = []
            periods.append(0)
            periods.append(False)
            periods.append({'year_start':vals['year_start'], 'year_end':vals['year_end'], })
            res.append(periods)
            vals['period_ids'] = res
        # 向会计科目位数表（easy.account.patten）表写入数据
        res = []
        acc_patten = []
        acc_patten.append(0)
        acc_patten.append(False)
        acc_patten.append({'acc_patten':'42222', 'is_default':True, })
        res.append(acc_patten)
        vals['acc_patten_ids'] = res
        # Set all entities as non-default entities.
        cr.execute("update easy_entity set default_entity=False;")
        return super(AccountEntity, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if 'isactive' in vals.keys():
            if vals['isactive']:
                vals['state'] = 'open'
            else:
                vals['state'] = 'closed'
        return super(AccountEntity, self).write(cr, uid, ids, vals, context=context)
    
    def send_as_default_entity(self, cr, uid, ids, context=None):
        cr.execute("update easy_entity set default_entity=False where id!=%d" % (ids[0]));
        cr.execute("update easy_entity set default_entity=True where id=%d" % (ids[0]))
        # update all accounts
        cr.execute("update easy_accounts set is_default_entity=False where entity_id!=%d" % (ids[0],))
        cr.execute("update easy_accounts set is_default_entity=True where entity_id=%d" % (ids[0],))
        # update all accounts-patten
        cr.execute("update easy_account_patten set is_default=False where entity_id!=%d" % (ids[0],))
        cr.execute("update easy_account_patten set is_default=True where entity_id=%d" % (ids[0],))
        # update all vouchers
        cr.execute("update easy_voucher set is_default_entity=False")
        cr.execute("""update easy_voucher set is_default_entity=True where id in(
            select id from easy_voucher
            where period_line_id in (
            select line.id from easy_period_line line
            inner join easy_period per on line.period_id=per.id
            inner join easy_entity ent on per.entity_id=ent.id
            where ent.id=%d
            ));""" % (ids[0],))
        # return self.write(cr, uid, ids, {'default_entity':True}, context),此处vals为何只有｛‘default_entity’｝一个键值对？？？
        return True
    
    def trial_balance(self, cr, uid, ids, context=None):
        # obj=self.pool.get('easy.accounts').search(cr,uid,[('entity_id','=',ids[0])],context)
        sql_str = """
        select sum(COALESCE(init_debit_amount,0))-sum(COALESCE(init_credit_amount,0)) diff 
        from easy_accounts where entity_id=%d
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['diff'] == 0:
            sql_str = """
            update easy_entity set close_init=True where id=%d
            """ % (ids[0],)
            cr.execute(sql_str)
            # inset initial balance into the first opening accounting period.
            init_sql = """
            insert into easy_accounts_balance_close(account_id,init_amount,period_line_id)
            select id,case direction when 'debit' then COALESCE(init_debit_amount,0)-
            COALESCE(init_credit_amount,0) else -COALESCE(init_debit_amount,0)+
            COALESCE(init_credit_amount,0) end balance,
                    (select id from easy_period_line 
                    where to_char(extract(year from period_start),'9999')||
                    to_char(extract(month from period_start),'99')=(
                    select to_char(extract(year from date_start_book),'9999')||
                    to_char(extract(month from date_start_book),'99') from easy_entity)) pid
            from easy_accounts
            where is_default_entity=True and
            COALESCE(init_credit_amount,0)+COALESCE(init_debit_amount,0)!=0
            and id not in (select account_id from easy_accounts_balance_close where period_line_id=
            (select min(period_line_id) from easy_accounts_balance_close)
            );         
            """
            cr.execute(init_sql)
            init_sql = """
            update easy_accounts_balance_close bc set init_amount=(
                select case direction when 'debit' then COALESCE(init_debit_amount,0)-
                COALESCE(init_credit_amount,0) else -COALESCE(init_debit_amount,0)+
                COALESCE(init_credit_amount,0) end balance
                from easy_accounts where id=bc.account_id
                )
                where account_id in (
                select id from easy_accounts where is_default_entity=True and
                COALESCE(init_credit_amount,0)+COALESCE(init_debit_amount,0)!=0
                );
            """
            cr.execute(init_sql)
        if res and res['diff'] != 0:
            msg = "There is a " + str(res['diff']) + ' difference.\n'
            msg += "Please check the initial balance!\nOr there are no accounts."
            raise osv.except_osv(_('Unblance!'), _(msg))
        return
    
    def reopen_initial(self, cr, uid, ids, context=None):
        # delete the initial balance from the first opening accounting period
        init_sql = """
        update easy_accounts_balance_close set init_amount=0 where period_line_id=
        (select id from easy_period_line 
            where to_char(extract(year from period_start),'9999')||
            to_char(extract(month from period_start),'99')=(
            select to_char(extract(year from date_start_book),'9999')||
            to_char(extract(month from date_start_book),'99') from easy_entity));
        """
        cr.execute(init_sql)
        return self.write(cr, uid, ids[0], {'close_init':False}, context)
    
        
AccountEntity()

class AccountsPeriod(osv.Model):
    
    actools = AccTools()
    _current_ts = actools.get_current_datetime()
    
    _name = 'easy.period'
    _auto = True
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity ID", required=True, ondelete='restrict'),
              'year_start':fields.date(u"Year Start", required=True),
              'year_end':fields.date(u"Year End", required=True),
              'line_ids':fields.one2many('easy.period.line', 'period_id', u"Line IDs"),
              'is_current':fields.boolean(u"Is Current Year?"),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
               'ts':_current_ts,
               'is_current':True,
               }
    _sql_constraints = [
                      ('start_gt_end_period', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ('unique_period', 'unique(entity_id,year_start,year_end)', 'Year start and year end must be unique per accounting period!'),
                      ]
    _sql = """create or replace view hanpeng_view_test
      as
      select * from easy_period
    """
    
    def create(self, cr, uid, vals, context=None):
        if vals['year_start'] and vals['year_end']:
            res = []
            actools = AccTools()
            y_s = actools.get_date_from_string(vals['year_start'])
            y_e = actools.get_date_from_string(vals['year_end'])
            months = actools.months_period(y_s, y_e)
            for i in range(len(months)):
                periods = []
                periods.append(0)
                periods.append(False)
                periods.append({'period_start':months[i][0], 'period_end':months[i][1], })
                res.append(periods)
            vals['line_ids'] = res
        return super(AccountsPeriod, self).create(cr, uid, vals, context=context)
       
AccountsPeriod()

class AccountsPeriodLine(osv.Model):
    
    def _get_voucher_staus(self, cr, uid, ids, fields, args, context):
        res = {}
        for i in ids:
            sql_str = """
            select count(id) ct from easy_voucher
            where period_line_id = %d and state!='book'
            and %d=(select min(id) from easy_period_line where period_id=(
            select period_id from easy_period_line where id=%d
            ) and isactive=TRUE)
            """ % (i, i, i,)
            cr.execute(sql_str)
            result = cr.dictfetchone()
            if result and result['ct'] > 0:
                res[i] = False
            elif result and result['ct'] == 0:
                res[i] = True
            else:
                res[i] = False
        return res
    
    def _get_voucher_quantity(self, cr, uid, ids, fields, args, context):
        res = {}
        for i in ids:
            sql_str = """
            select count(id) ct from easy_voucher
            where period_line_id = %d
            """ % (i,)
            cr.execute(sql_str)
            result = cr.dictfetchone()
            if result:
                res[i] = result['ct']
        return res
    
    def _get_not_book_voucher_quantity(self, cr, uid, ids, fields, args, context):
        res = {}
        for i in ids:
            sql_str = """
            select count(id) ct from easy_voucher
            where period_line_id = %d and state!='book'
            """ % (i,)
            cr.execute(sql_str)
            result = cr.dictfetchone()
            if result:
                res[i] = result['ct']
        return res
    
    def _get_nonebooked_voucher_quantity(self, cr, uid, ids, context):
        for i in ids:
            sql_str = """
            select count(id) ct from easy_voucher
            where period_line_id = %d and state!='book'
            """ % (i,)
            cr.execute(sql_str)
            result = cr.dictfetchone()
            if result and result['ct'] > 0:
                return False
        return True
    
    _name = 'easy.period.line'
    _columns = {
              'period_id':fields.many2one('easy.period', string=u"Period ID", required=True, ondelete='restrict'),
              'period_start':fields.date(string=u"Accounting Period Start", required=True),
              'period_end':fields.date(string=u"Accounting Period End", required=True),
              'is_current':fields.boolean(u"Is Current Year?"),  # If fiscal year is current business year.
              'isactive':fields.boolean(u"Active"),  # if current period is closed,this field is set to False.Default is True.
              'state':fields.selection([('active', u'Active'), ('close', u"Closed")], string=u"Status", required=True),
              'check_close_is_ready':fields.function(_get_voucher_staus, type="boolean", string=u"Whether Close?"),
              'voucher_quantity':fields.function(_get_voucher_quantity, type="integer", string=u"Voucher Quantity"),
              'voucher_not_book_quantity':fields.function(_get_not_book_voucher_quantity, type="integer", string=u"None-booked Voucher Quantity"),
              }
    _defaults = {
               'isactive':True,
               'is_current':True,
               'state':'active',
               }
    _sql_constraints = [
                      ('unique_year_month_per_period', 'unique(period_id,period_start,period_end)', 'Accounting Year-month must be unique per period.'),
                      ]
    
    def name_get(self, cr, uid, ids, context=None):
        if not ids:
            return []
        if isinstance(ids, (int, long)):
                    ids = [ids]
        reads = self.read(cr, uid, ids, ['period_start', 'period_end'], context=context)
        res = []
        for record in reads:
            name = record['period_start'] + ' ~ ' + record['period_end']
            res.append((record['id'], name))
        return res
    
    def close_current_period(self, cr, uid, ids, context=None):
        # if there exists months before current month which are not been closed,refuse to close current month.
        sql_str = """
        select count(id) ct from easy_period_line where period_id=(
        select period_id from easy_period_line where id=%d) 
        and id<%d and state='active';
        """ % (ids[0], ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['ct'] > 0:
            raise osv.except_osv(_('Refuse!'), _('there exist month(s) before current month \nwhich are not been closed!'))
        # if there exist vouchers have not been posted,refuse to close this period!
        nonebooked_voucher_quantity = self._get_nonebooked_voucher_quantity(cr, uid, ids, context)
        if not nonebooked_voucher_quantity:
            raise osv.except_osv(_('Refuse!'), _('there exist voucher(s) have not been posted, \nplease post them!'))
        # make vouchers in this period sequential if needed.
        self._make_voucher_sequential(cr, uid, ids, context)
        # auto-create a new financial year
        self._auto_create_account_period(cr, uid, ids, context)
        # insert accounts balance.
        self._compute_balance_when_close(cr, uid, ids, context)
        return self.write(cr, uid, ids, {'state':'close', 'isactive':False}, context)
    
    def open_current_period(self, cr, uid, ids, context=None):
        # if there exists months after current month which are not been reopen(that is ,these months has been closed),refuse to reopen current month.
        sql_str = """
        select count(id) ct from easy_period_line where period_id=(
        select period_id from easy_period_line where id=%d) 
        and id>%d and state='close';
        """ % (ids[0], ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['ct'] > 0:
            raise osv.except_osv(_('Refuse!'), _('there exist month(s) after current month \nwhich are not been reopen!'))
        # update all balance=0 in this period
        sql_str = """
        update easy_accounts_balance_close set (debit_amount,credit_amount,balance)=(null,null,null)
         where period_line_id=%d
        """ % (ids[0],)
        cr.execute(sql_str)
        #
        return self.write(cr, uid, ids, {'state':'active', 'isactive':True}, context)
    
    def _make_voucher_sequential(self, cr, uid, ids, context=None):
        #
        sql_str = """
        update easy_voucher vou set code1=(
                with info as(
                select id,code,code1,voucher_date,period_line_id,
                rank() over(partition by period_line_id order by code) sn
                 from easy_voucher)
                select sn from info where code!=sn and id=vou.id
        )
        where id in (
                with info as(
                select id,code,code1,voucher_date,period_line_id,
                rank() over(partition by period_line_id order by code) sn
                 from easy_voucher)
                select id from info where code!=sn
        ) and code1 is null and period_line_id=%d
        and 1=(
            select case when force_voucher_seq=True then 1 else 0 end from easy_base_config_settings
        );
        """ % (ids[0],)
        cr.execute(sql_str)
        return
    
    def _compute_balance_when_close(self, cr, uid, ids, context=None):
        # insert data into accounts balance.
        sql_str = """
        insert into easy_accounts_balance_close(account_id,debit_amount,credit_amount,balance,period_line_id)
        with info as(
                select line.account_id,sum(debit_amount) debit,sum(credit_amount) credit
                from easy_voucher_line line
                inner join easy_voucher vou on line.voucher_id=vou.id
                where vou.is_default_entity=True and vou.period_line_id=%d
                group by line.account_id)
            select account_id,debit,credit,
            case acc.direction when 'debit' then coalesce(debit,0)-COALESCE(credit,0)
            else -COALESCE(debit,0)+COALESCE(credit,0) end balance,%d
            from info
            inner join easy_accounts acc on acc.id=info.account_id
            where info.account_id not in (
                select account_id from easy_accounts_balance_close where period_line_id=%d
                );
        """ % (ids[0], ids[0], ids[0])
        cr.execute(sql_str)
        sql_str = """
        update easy_accounts_balance_close bc set debit_amount=
         (select debit from easy_accounts_balance_for_period where account_id=bc.account_id and bc.period_line_id=period_line_id),
        credit_amount=(select credit from easy_accounts_balance_for_period where account_id=bc.account_id and bc.period_line_id=period_line_id)
        where period_line_id=%d and account_id in (
        select account_id from easy_voucher_line where voucher_id in 
        (select id from easy_voucher where period_line_id=%d)
        );
        
        """ % (ids[0], ids[0],)
        cr.execute(sql_str)
        sql_str = """
        update easy_accounts_balance_close set balance=COALESCE(init_amount,0)+COALESCE(debit_amount,0)-COALESCE(credit_amount,0)
        where account_id in (select id from easy_accounts where is_default_entity=True and direction='debit') and period_line_id =%d;
        """ % (ids[0],)
        cr.execute(sql_str)
        sql_str = """
        update easy_accounts_balance_close set balance=COALESCE(init_amount,0)-COALESCE(debit_amount,0)+COALESCE(credit_amount,0)
        where account_id in (select id from easy_accounts where is_default_entity=True and direction='credit') and period_line_id =%d;
        """ % (ids[0],)
        cr.execute(sql_str)
        # insert into data into the next accounting period as init balance.
        return
    def _create_account_period(self, cr, uid, ids, period_id, entity_id, context=None):
        sql_str = """
        select year_start,year_end from easy_period where id=%d
        """ % (period_id,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        DATETIME_FORMAT = "%Y-%m-%d"
        year_start = datetime.datetime.strptime(res['year_start'], DATETIME_FORMAT)
        year_end = datetime.datetime.strptime(res['year_end'], DATETIME_FORMAT)
        year_start_year = year_start.year + 1
        year_start_month = year_start.month
        year_start_day = year_start.day
        year_end_year = year_end.year + 1
        year_end_month = year_end.month
        year_end_day = year_end.day
        # next_year_start=datetime.date(year_start_year, year_start_month, year_start_day)
        # next_year_end=datetime.date(year_end_year, year_end_month, year_end_day)
        next_year_start = str(year_start_year) + '-' + str(year_start_month).rjust(2, '0') + '-' + str(year_start_day).rjust(2, '0')
        next_year_end = str(year_end_year) + '-' + str(year_end_month).rjust(2, '0') + '-' + str(year_end_day).rjust(2, '0')
        # check if next year has existed.
        sql_str = """
        select id from easy_period where extract(year from year_start)=%d and extract(month from year_start)=%d
        """ % (year_start_year, year_start_month,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        print res
        if res:
            return
        # create next fiscal year
        fy_obj = self.pool.get('easy.period')
        fy_obj.create(cr, uid, {'entity_id':entity_id, 'year_start':next_year_start, 'year_end':next_year_end, 'is_current':True}, context)
        return
    
    def _auto_create_account_period(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        sql_str = """
        with info as(
        select period_start,id,period_id,
        max(period_start) over() maxdate
        from easy_period_line where period_id=%d)
        select info.id-%d cu,pd.entity_id from info
        inner join easy_period pd on info.period_id=pd.id
        where maxdate=period_start;
        """ % (obj.period_id.id, ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['cu'] == 0:
            # auto-create the next fiscal year
            self._create_account_period(cr, uid, ids, obj.period_id.id, res['entity_id'], context)
        return
        
    
AccountsPeriodLine()


class AccountsPatten(osv.Model):
    
    _name = 'easy.account.patten'
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity ID", required=True),
              'acc_patten':fields.char(size=20, required=True, string=u"Accounts code Patten"),
              'is_default':fields.boolean(u"Is a default entity?"),
              }    
    _sql_constraints = [
                      ('unique_accode_patten', 'unique(entity_id,acc_patten)', 'Accounts code patten must be unique!'),
                      ('account_patten', "check(acc_patten similar to '\d+')", 'Accounts code does not match code patten!'),
                      ]
    _defaults = {
               'acc_patten':'42222',
               'is_default':True,
               }
    
class Accounts(osv.Model):
    
    def _get_default_entity(self, cr, uid, ids, context=None):
        # 返回值是eids[0],是标量值，如果是eids，则是列表格式，保存时会出错。
        entity = self.pool.get('easy.entity')
        eids = entity.search(cr, uid, [('default_entity', '=', True), ], context)
        if not eids:
            return []
        return eids[0]
    
    def _get_account_patten_running(self, cr, uid, ids, fields, args, context=None):
        res = {}
        # 获取当前会计科目对应的会计主体ID
#         entity=self.pool.get('easy.entity')
#         eids=entity.search(cr,uid,[('default_entity','=',True),],context)
        sql_str = """
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result = cr.dictfetchone()
        if result and result['acc_patten']:
            res[ids[0]] = result['acc_patten']
        return res
    
    def _get_account_patten_designing(self, cr, uid, ids, context=None):
        sql_str = """
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result = cr.dictfetchone()
        if result and result['acc_patten']:
            return result['acc_patten']
        return

        
    
    def _get_account_depth(self, cr, uid, ids, fields, args, context=None):
        res = {}
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select aid,acode,aname,adepth from info
            order by adepth desc;          
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchall()
            if sql_res:
                res[ids[0]] = ""
                for line in sql_res:
                    res[ids[0]] += line['acode'] + ' ' + line['aname'] + '>'
            else:
                res[ids[0]] = "None"
        return res
    
    def _get_account_depthnum(self, cr, uid, ids, context=None):
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select max(adepth) max_depth from info;
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchone()
            if sql_res:
                return sql_res['max_depth']
            else:
                return 0
        return
    
    def _check_account_code(self, cr, uid, ids, context=None):
        # 检查会计科目的位数与ACCOUNT_PATTEN定义的是否一致
        acc_patten = self._get_account_patten_designing(cr, uid, ids, context=None)
        obj = self.browse(cr, uid, ids[0], context=context)
        if (not obj.parent_id) and len(obj.code) != int(acc_patten[0]):
            return False
        if obj.parent_id:
            max_level = self._get_account_depthnum(cr, uid, ids, context)
            current_length = 0
            for i in range(max_level):
                current_length += int(acc_patten[i])
            if current_length != len(obj.code):
                return False
        return True
    
    def _check_account_code_match_parent(self, cr, uid, ids, context=None):
        # 检查子科目与上级科目之间的编码前几位是否相同
        sub_account = self.browse(cr, uid, ids[0], context)
        if sub_account.parent_id:
            parent_account = self.read(cr, uid, sub_account.parent_id.id, ['code'], context)
            parent_account_code = parent_account['code']
            sub_account_code = sub_account.code[0:len(parent_account_code)]
            if sub_account_code != parent_account_code:
                return False        
        return True
    
    def _get_account_direction(self, cr, uid, ids, fields, args, context=None):
        res = {}
        for i in ids:
            obj = self.read(cr, uid, i, ['direction'], context)
            if obj and obj['direction']:
                res[i] = ('Debit' if (obj['direction'] == 'debit') else "Credit")
        return res   
    
    def name_get(self, cr, uid, ids, context=None):
        if not ids:
            return []
        if isinstance(ids, (int, long)):
                    ids = [ids]
        res = []
        
        for i in ids:
            obj = self.browse(cr, uid, i, context)
            account_code = obj.code
            sql_str = """
            select acc_name,lv from easy_accounts_view where root_id=%d
            """ % (i,)
            cr.execute(sql_str)
            result = cr.dictfetchall()
            if result:
                acc_name = ''
                for line in result:
                    acc_name += line['acc_name'] + '>'
                acc_name = acc_name[0:len(acc_name) - 1]
                res.append((i, obj.code + ' ' + acc_name))
        return res 

    _name = 'easy.accounts'
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Accounting Entity", required=True, readonly=True),
              'code':fields.char(size=100, required=True, string=u"Account Code"),
              'show_name':fields.char(size=100, required=True, string=u"Account Name"),
              'name':fields.char(size=120, readonly=True, string=u"Account Full Name"),
              'parent_id':fields.many2one('easy.accounts', u"Parent Account", ondelete='restrict', domain=[('is_default_entity', '=', True), ('voucher_ids', '=', None)]),
              'child_ids':fields.one2many('easy.accounts', 'parent_id', u'Direct Children Accounts:', readonly=True),
              'voucher_ids':fields.one2many('easy.voucher.line', 'account_id', u'Voucher IDs', readonly=True),
              'direction':fields.selection([('debit', u"Debit"), ('credit', u'Credit'), ], u"Balance Direction", required=True),
              'classification':fields.selection([('asset', u'Asset'),
                                                 ('liability', u"Liability"),
                                                 ('ownership', u"Owner's Equity"),
                                                 ('income', u"Income"),
                                                 ('expense', u'Expense'),
                                                 ], u"Classification", required=True),
              'is_default_entity':fields.boolean(string=u"Is Default Entity?"),
              'account_patten':fields.function(_get_account_patten_running, type='char', string=u"Account Patten"),
              'account_patten2':fields.char(size=100, string=u"Account Patten", readonly=True),
              'account_depth':fields.function(_get_account_depth, type='char', string=u"Account Depth"),
              'isactive':fields.boolean(u"Active", readonly=True),
              'type':fields.selection([('view', u'View'), ('comm', u'Common')], string=u'Type', required=True),
              'remark':fields.text(u"Remark:"),
              'state':fields.selection([('edit', u"Editing"), ('confirm', u"Confirmed"), ('close', u"Closed")], u"Status", required=True, readonly=True),
              'init_debit_amount':fields.float(u"Init Debit Amount", digits=(12, 2)),
              'init_credit_amount':fields.float(u"Init Credit Amount", digits=(12, 2)),
              'init_direction':fields.function(_get_account_direction, type='char', string=u"Direction"),
              }
    _order = 'code'
    _defaults = {
               'isactive':True,
               'entity_id':_get_default_entity,
               'account_patten2':_get_account_patten_designing,
               'is_default_entity':True,
               'state':'edit',
               'type':'comm',
               }
    _sql_constraints = [
                      ('unique_chart_code', 'unique(entity_id,code)', 'Account code must be unique in an accounting entity!'),
                      ('check_account_code', "check(code similar to '\d+')", 'Account code must be digits!'),
                      ]
    _constraints = [
                  (_check_account_code, 'Account code length does not match the account patten!', ['Account Code']),
                  (_check_account_code_match_parent, 'Account code must match the parent code', ['Acccount Code']),
                  ]
    def _set_accounts_type_onwrite(self, cr, uid, ids, context=None):
        # check if current account's parent account has children accounts except current account.
        # if has no more children accounts,update it as common.
        for i in ids:
            sql_str = """
            update easy_accounts set type='comm' where id=(
            select parent_id from easy_accounts where id=%d
            ) and 0=(select count(id) cid from easy_accounts where parent_id=(
            select parent_id from easy_accounts where id=%d)
            and id !=%d);
            """ % (i, i, i,)
            cr.execute(sql_str)
        return
    
    def write(self, cr, uid, ids, vals, context=None):
        # if init balace has been closed,refuse write
        sql_str = """
        select close_init from easy_entity where id in (
        select entity_id from easy_accounts where id=%d);
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['close_init'] and ('init_credit_amount' in vals.keys() or 'init_debit_amount' in vals.keys()):
            raise osv.except_osv(_('Refuse to write!'), _('Init Balance has been closed,\nyou can not modify initial balance!'))
        #
        code = ""
        show_name = ""
        sql_str = """
            select code,show_name from easy_accounts where id=%d
            """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['code'] and res['show_name']:
            code = res['code']
            show_name = res['show_name']
        
        if 'code' in vals.keys():
            code = vals['code']
        if 'show_name' in vals.keys():
            show_name = vals['show_name']
        vals['name'] = code + ' ' + show_name
        # update parent account's type
        self._set_accounts_type_onwrite(cr, uid, ids, context)
        if 'parent_id' in vals.keys() and vals['parent_id']:
            sql_str = """
            update easy_accounts set type='view' where id=%d and type='comm';
            """ % (vals['parent_id'],)
            cr.execute(sql_str)
        #
        return super(Accounts, self).write(cr, uid, ids, vals, context=context)
    
    def create(self, cr, uid, vals, context=None):
        vals['name'] = vals['code'] + ' ' + vals['show_name']
        vals['state'] = 'confirm'
        # if it has parent account,then update its parent type as view
        if vals['parent_id']:
            sql_str = """
            update easy_accounts set type='view' where id=%d and type!='view';
            """ % (vals['parent_id'],)
            cr.execute(sql_str)
        #
        return super(Accounts, self).create(cr, uid, vals, context=context)
    
    def unlink(self, cr, uid, ids, context=None):
        # if init balace has been closed,refuse write
        sql_str = """
        select close_init from easy_entity where id in (
        select entity_id from easy_accounts where id=%d);
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['close_init']:
            raise osv.except_osv(_('Refuse to write!'), _('Init Balance has been closed,\nyou can not delete them!'))
        #
        self._set_accounts_type_onwrite(cr, uid, ids, context)
        return super(Accounts, self).unlink(cr, uid, ids, context=context)
    
    def set_account_code_from_parent(self, cr, uid, ids, parent_id, context):
        # 根据父项科目，自动生成下级科目 编码
        # 得到科目的位数级次定义
        # 先不做，这个功能未必实用
        # acc_patten=self._get_account_patten_designing(cr,uid,ids,context)
        return
    
    def onchange_parent_id(self, cr, uid, ids, parent_id, context=None):
        val = {'direction':None, 'classification':None, 'code':None, 'child_ids':None, 'child_ids':[]}
               
        # 得到目前会计科目的余额方向和类型
        if parent_id:
            # if current parent id has been used in vouchers,then raise error!
#             vou_obj=self.pool.get('easy.voucher.line').search(cr,uid,[('account_id','=',parent_id),],context)
#             if vou_obj:
#                 return {'value':{'parent_id':None}}
#                 raise osv.except_osv(_('Refuse!'), _('Current voucher has been used in vouchers,\nit is refused to add child!'))
            #
            parent_info = self.browse(cr, uid, parent_id, context)
            # 取出父项科目的直属下级科目
            children = []
            obj = self.search(cr, uid, [('parent_id', '=', parent_id), ], context)
            if obj:
                children = obj
            val = {'direction':parent_info.direction, 'classification':parent_info.classification, 'code':parent_info.code, 'child_ids':children}
        return {'value':val}
    
#     def set_account_as_confirm(self,cr,uid,ids,context=None):
#         return self.write(cr, uid, ids, {'state': 'confirm','isactive':True}, context=context)
    
    def get_children_accounts(self, cr, uid, ids, context=None):
        account_list = "Current account and all its children accounts(as follows)"
        account_list += '\n' + "will be closed. All closed accounts will "
        account_list += '\n' + "never occur in voucher making but can be queried in history voucher."
        account_list += '\n' + "If you want to reopen these closed accounts,"
        account_list += '\n' + "you must reopen them by one by,there is no batch-reopen operation for you.\n"
        sql_str = """
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.aid=easy_accounts.parent_id
            )
            select aid,aname,adepth,state from info where state not in ('close')
            order by adepth;
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchall()
        if res and len(res) > 1:
            for info in res:
                account_list += '\nX ' + info['aname'] + ', current state:' + info['state']
        elif res and len(res) == 1:
            account_list = "N"
        return account_list
    
    def get_parent_accounts(self, cr, uid, ids, context=None):
        account_list = "Current account and all its parent accounts(as follows)"
        account_list += '\n' + "will be reopen. Would you continue?"
        sql_str = """
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select aid,aname,adepth,state from info where state not in ('confirm')
            order by adepth desc;
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchall()
        if res and len(res) > 1:
            for info in res:
                account_list += '\nX ' + info['aname'] + ', current state:' + info['state']
        elif res and len(res) == 1:
            account_list = "N"
        return account_list
    
    def set_account_as_closed(self, cr, uid, ids, context=None):
        children_accounts_num = len(self.get_children_accounts(cr, uid, ids, context))
        # 如果返回值为1，则表示只有当前科目而无下级科目需要更新。
        if children_accounts_num == 1:
            return self.write(cr, uid, ids, {'state': 'close', 'isactive':False}, context=context)
        p_obj = self.browse(cr, uid, ids[0], context)
        ir_model_data = self.pool.get('ir.model.data')
        compose_form_id = ir_model_data.get_object_reference(cr, uid, 'easybook', 'close_account_form_view')[1]
        ctx = dict(context)
        ctx.update({
            'default_user_id':uid,
            'default_account_id':ids[0],
            'default_desc':self.get_children_accounts(cr, uid, ids, context),
        })    
        return {
            'name':'Close Accounts',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'easy.closeaccount.log',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'nodestroy': True,
            'target': 'new',
            'context': ctx,
        }
        
        
    def set_account_as_confirm(self, cr, uid, ids, context=None):
        parent_accounts_num = len(self.get_parent_accounts(cr, uid, ids, context))
        # 如果返回为1，则表示当前科目封存父项科目。
        if parent_accounts_num == 1:
            return self.write(cr, uid, ids, {'state': 'confirm', 'isactive':True}, context=context)
        p_obj = self.browse(cr, uid, ids[0], context)
        ir_model_data = self.pool.get('ir.model.data')
        compose_form_id = ir_model_data.get_object_reference(cr, uid, 'easybook', 'reopen_account_form_view')[1]
        ctx = dict(context)
        ctx.update({
            'default_user_id':uid,
            'default_account_id':ids[0],
            'default_desc':self.get_parent_accounts(cr, uid, ids, context),
        })    
        return {
            'name':'Close Accounts',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'easy.closeaccount.log',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'nodestroy': True,
            'target': 'new',
            'context': ctx,
        }
        
Accounts()


class CloseAccountLog(osv.TransientModel):
    
    _name = 'easy.closeaccount.log'
    _columns = {
              'account_id':fields.integer(u"Account ID"),
              'user_id':fields.integer(u"User"),
              'desc':fields.text(u"Description", readonly=True),
              }
    
    def close_accounts(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        sql_str = """
            update easy_accounts set (state,isactive)=('close',False)
            where id in (
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.aid=easy_accounts.parent_id
            )
            select aid from info where state not in ('close'));
        """ % (obj.account_id,)
        cr.execute(sql_str)
        return {'type': 'ir.actions.act_window_close'}
    
    def reopen_accounts(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        sql_str = """
            update easy_accounts set (state,isactive)=('confirm',True)
            where id in (
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts 
                        on info.parent_id=easy_accounts.id
            )
            select aid from info where state not in ('confirm'));
        """ % (obj.account_id,)
        cr.execute(sql_str)
        return {'type': 'ir.actions.act_window_close'}

CloseAccountLog()


class AccountVoucher(osv.Model):
    
    def _get_default_period_line(self, cr, uid, ids, context=None):
        sql_str = """
        select min(line.id) mid
        from easy_period_line line
        inner join easy_period period on line.period_id=period.id
        inner join easy_entity entity on period.entity_id=entity.id
        where entity.default_entity=True and line.isactive=True;
        """
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['mid']:
            return res['mid']
        return False
    
    def _get_maker(self, cr, uid, ids, context=None):
        sql_str = """
            select id from res_partner where id=(
            select partner_id from res_users where id=%d
            )
            """ % (uid,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['id']:
            return res['id']
        return None
    
    def _get_voucher_sn(self, cr, uid, ids, context=None):
        voucher_sn = 1
        period_line_id = self._get_default_period_line(cr, uid, ids, context)
        if period_line_id:
            sql_str = """
            select max(vou.code) id_num from easy_voucher vou
            inner join easy_period_line line on vou.period_line_id=line.id
            inner join easy_period per on line.period_id=per.id
            inner join easy_entity ent on per.entity_id=ent.id
            where ent.default_entity=True and line.id=%d
            """ % (period_line_id,)
            cr.execute(sql_str)
            res = cr.dictfetchone()
            if res and res['id_num']:
                voucher_sn = res['id_num'] + 1
        return voucher_sn
    
        
    def _get_default_voucher_date(self, cr, uid, ids, context=None):
        period_line_id = self._get_default_period_line(cr, uid, ids, context)
        ticks = time.localtime(time.time())
        default_voucher_date = str(ticks[0]) + '-' + str(ticks[1]).rjust(2, '0') + '-' + str(ticks[2]).rjust(2, '0')
        sql_str = """
         select 
            extract(year from period_start) yy,
            extract(month from period_start) mm
            from easy_period_line
         where id=%d
         """ % (period_line_id,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res:
            default_voucher_date = str(int(res['yy'])) + '-' + str(int(res['mm'])).rjust(2, '0') + '-' + str(ticks[2]).rjust(2, '0')
        return default_voucher_date
    
    def _check_voucherdate(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        DATETIME_FORMAT = "%Y-%m-%d"
        voucherdate = datetime.datetime.strptime(obj.voucher_date, DATETIME_FORMAT)
        v_yy = voucherdate.year
        v_mm = voucherdate.month
        p_date = self._get_default_voucher_date(cr, uid, ids, context)
        p_date = datetime.datetime.strptime(p_date, DATETIME_FORMAT)
        p_yy = p_date.year
        p_mm = p_date.month
        if v_yy == p_yy and v_mm == p_mm:
            return True
        return False
    
    def _get_desc(self, cr, uid, ids, fields, args, context=None):
        result = {}
        for i in ids:
            sql_str = """
            with info as(
            select id,description,min(id) over() from easy_voucher_line
            where voucher_id=%d)
            select description from info where id=min;
            """ % (i,)
            cr.execute(sql_str)
            res = cr.dictfetchall()
            if res:
                for x in res:
                    result[i] = x['description']
            else:
                result[i] = None
        return result
    
    def _get_debit_total_amount(self, cr, uid, ids, fields, args, context=None):
        result = {}
        for i in ids:
            sql_str = """
            select sum(debit_amount) debit,sum(credit_amount) credit from easy_voucher_line
            where voucher_id=%d
            """ % (i,)
            cr.execute(sql_str)
            res = cr.dictfetchall()
            if res:
                for x in res:
                    result[i] = x['debit']
            else:
                result[i] = None
        return result
    
    def name_get(self, cr, uid, ids, context=None):
        result = []
        for i in ids:
            sql_str = """
            select id,
                to_char(extract(year from voucher_date),'9999')||'-'||
                lpad(trim(both ' ' from to_char(extract(month from voucher_date),'99')),2,'0')||','||
                'No.'||lpad(trim(both ' ' from to_char(code,'9999999') ),3,'0') descr
                from easy_voucher where id=%d;
            """ % (i,)
            cr.execute(sql_str)
            res = cr.dictfetchall()
            if res:
                for x in res:
                    result.append((x['id'], x['descr']))
        return result
    
    def _get_voucher_no(self, cr, uid, ids, fields, args, context=None):
        res = {}
        vou_obj = self.browse(cr, uid, ids, context)
        for line in vou_obj:
            if line.code1:
                res[line.id] = line.code1
            else:
                res[line.id] = line.code
        return res
    
        
    _name = 'easy.voucher'
    _columns = {
              'period_line_id':fields.many2one('easy.period.line', u"Periods", required=True, readonly=True),
              'code':fields.integer(u"Voucher Number", required=True, readonly=True),
              'code1':fields.integer(u"Voucher Number(Actural)", readonly=True),
              'actural_code':fields.function(_get_voucher_no, type="integer", string=u"Voucher No."),
              'voucher_date':fields.date(u"Voucher Date", required=True, readonly=True, states={'make':[('readonly', False)]}),
              'name':fields.function(_get_desc, type='text', string=u"Description"),
              'total_amount':fields.function(_get_debit_total_amount, type='float', string=u"Amount Total"),
              'maker':fields.many2one('res.partner', u"Maker", required=True, readonly=True),
              'approver':fields.many2one('res.partner', u"Approver", readonly=True),
              'postpsn':fields.many2one('res.partner', u"Post", readonly=True),
              'doc_num':fields.integer(u"Documents Number", readonly=True, states={'make':[('readonly', False)]}),
              'voucher_line_ids':fields.one2many('easy.voucher.line', 'voucher_id', u"Voucher line", readonly=True, states={'make':[('readonly', False)]}),
              'is_default_entity':fields.boolean(u'Is Default Entity?'),
              'state':fields.selection([('make', u'Making'), ('approve', u'Approved'), ('book', u'Posted')], string=u"Status", readonly=True, required=False),
              }
    _defaults = {
               'doc_num':0,
               'period_line_id':_get_default_period_line,
               'maker':_get_maker,
               'code':_get_voucher_sn,
               'is_default_entity':True,
               'voucher_date':_get_default_voucher_date,
               'state':'make',
               }
    _sql_constraints = [
                      ('unique_voucher_code', 'unique(period_line_id,code)', 'Voucher sn must be unique!'),
                      ('code_gt_zero', 'check(code>=0)', 'Voucher SN must be greater than zero!'),
                      ]
    
    def unlink(self, cr, uid, ids, context=None):
        # if current month has been closed,refuse to delete voucher(s).
        obj = self.browse(cr, uid, ids, context)
        for line in obj:
            if line and line.state in ('book', 'approve'):
                raise osv.except_osv(_('Refuse!'), _('Voucher has been posted or approved,\nYou are refused to cancel post!'))
            period_obj = self.pool.get('easy.period.line').browse(cr, uid, line.period_line_id.id, context)
            if period_obj.state in ('close'):
                raise osv.except_osv(_('Refuse!'), _('Accounting period has been closed,\nYou are refused to cancel post!'))
        #
        return super(AccountVoucher, self).unlink(cr, uid, ids, context)
    
    def _check_total_value(self, cr, uid, ids, context=None):
        debit_total = 0
        credit_total = 0
        obj = self.pool.get('easy.voucher.line')
        line_ids = obj.search(cr, uid, [('voucher_id', '=', ids[0]), ], context)
        obj = self.browse(cr, uid, line_ids, context)
        if len(obj) <= 1:
            return False
        for line in obj:
            voucher_line = self.pool.get('easy.voucher.line').read(cr, uid, line.id, context)
            debit_total += voucher_line['debit_amount']
            credit_total += voucher_line['credit_amount']
        if debit_total != credit_total:
            return False
        return True
    
    def voucher_approve(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids[0], {'state':'approve', 'approver':self._get_maker(cr, uid, ids, context)}, context)
    
    def voucher_book(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids[0], {'state':'book', 'postpsn':self._get_maker(cr, uid, ids, context)}, context)
    
    def voucher_cancel_book(self, cr, uid, ids, context=None):
        # if current accounting period has been closed,refuse to cancel_book
        for i in ids:
            period_line_id = self.browse(cr, uid, i, context).period_line_id.id
            obj = self.pool.get('easy.period.line').browse(cr, uid, period_line_id, context).state
            if obj and obj == 'close':
                raise osv.except_osv(_('Refuse!'), _('Current month has been closed,\nYou are refused to cancel post!'))       
        #
        return self.write(cr, uid, ids[0], {'state':'approve', 'postpsn':None}, context)
    
    def voucher_cancel_approve(self, cr, uid, ids, context=None):
        return self.write(cr, uid, ids[0], {'state':'make', 'approver':None}, context)
    
    def create(self, cr, uid, vals, context=None):
        return super(AccountVoucher, self).create(cr, uid, vals, context=context)
    
    _constraints = [
                  (_check_voucherdate, 'Voucher date must be during in accounting period!', ['Voucher Date Error']),
                  (_check_total_value, 'Unbalanced or no voucher line.', ['Value Check']),
                  ]
    
AccountVoucher()

class AccountVoucherLine(osv.Model):
    
    _name = 'easy.voucher.line'
    _columns = {
              'voucher_id':fields.many2one('easy.voucher', u"Voucher ID", required=True, ondelete='cascade'),
              'account_id':fields.many2one('easy.accounts', u"Accounts", required=True, domain=[('is_default_entity', '=', True), ('type', '=', 'comm'), ('isactive', '=', True)]),
              'description':fields.char(size=200, string=u"Description"),
              'debit_amount':fields.float(u"Debit", digits=(12, 2)),
              'credit_amount':fields.float(u"Credit", digits=(12, 2)),
              }
    _sql_constraints = [
                      ('check_amount', 'check(COALESCE(debit_amount,0)+COALESCE(credit_amount,0)!=0)', 'Amount must not be zero!'),
                      ]
    
    _defaults = {
               'debit_amount':None,
               'credit_amount':None,
               }
    def _check_value(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        if obj.debit_amount and obj.credit_amount:
            return False
        return True
    
    def name_get(self, cr, uid, ids, context=None):
        result = []
        for i in ids:
            sql_str = """
            select line.id,
                to_char(extract(year from vou.voucher_date),'9999')||'-'||
                lpad(trim(both ' ' from to_char(extract(month from vou.voucher_date),'99')),2,'0')||','||
                'No.'||lpad(trim(both ' ' from to_char(code,'9999999') ),3,'0')||','||line.description descr
                from easy_voucher_line line
                inner join easy_voucher vou on line.voucher_id=vou.id
                where line.id=%d;
            """ % (i,)
            cr.execute(sql_str)
            res = cr.dictfetchall()
            if res:
                for x in res:
                    result.append((x['id'], x['descr']))
        return result
    
    _constraints = [
                 (_check_value, 'debit and credit can not all have value at the same time!', ['Value Error!']),
                 ]
    

AccountVoucherLine()

class AccountBalanceForClose(osv.Model):
    _name = 'easy.accounts.balance.close'
    _columns = {
              'period_line_id':fields.many2one('easy.period.line', u"Period Line ID"),
              'account_id':fields.many2one('easy.accounts', u"Account ID"),
              'init_amount':fields.float(u"Init Debit Amount", digits=(12, 2)),
              'debit_amount':fields.float(u"Debit Amount", digits=(12, 2)),
              'credit_amount':fields.float(u"Credit Amount", digits=(12, 2)),
              'balance':fields.float(u"Balance", digits=(12, 2)),
              }
    _sql_constraints = [
                      ('unique_accounts_balance', 'unique(period_line_id,account_id)', 'Account must unique per accounting period!'),
                      ]
AccountBalanceForClose()

class AccountVoucherBatchOperation(osv.TransientModel):
    
    def _get_maker(self, cr, uid, ids, context=None):
        sql_str = """
            select id from res_partner where id=(
            select partner_id from res_users where id=%d
            )
            """ % (uid,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['id']:
            return res['id']
        return None
    
    _name = 'easy.voucher.batch.operation'
    _columns = {
              'all_voucher_ids':fields.text(u"All Voucher IDs"),
              'descr':fields.text(u"Attention:", readonly=True),
              }
    _defaults = {
               'descr':"""
1,Vouchers are better in the same accounting period,though vouchers which are not in the same can be done with.\n
2,All vouchers must has the same status,that is ,if you want to cancel post,then all vouchers must all in posted status.\n
3,If accounting period has been closed,you are refuse to batch cancel post.
               """,
               }
    
    def _get_voucher_ids_for_batch(self, cr, uid, ids, context=None):
        voucher_ids = self.browse(cr, uid, ids[0], context).all_voucher_ids
        voucher_ids = voucher_ids.replace(']', '')
        voucher_ids = voucher_ids.replace('[', '')
        voucher_ids = voucher_ids.split(',')
        voucher_ids = [int(x) for x in voucher_ids]
        return voucher_ids
    
    def voucher_batch_cancel_post(self, cr, uid, ids, context=None):
        voucher_ids = self._get_voucher_ids_for_batch(cr, uid, ids, context)
        # get accounting period line ids
        period_line = self.pool.get('easy.voucher').read(cr, uid, voucher_ids, ['period_line_id'], context)
        period_line_ids = []
        for i in period_line:
            period_line_ids.append(i['period_line_id'][0])
        period_line = self.pool.get('easy.period.line').browse(cr, uid, period_line_ids, context)
        # if period has been closed ,refuse to cancel!
        for i in period_line:
            if i.state == 'close':
                raise osv.except_osv(_('Refuse!'), _(str(i.period_start) + '~' + str(i.period_end) + ' has been closed,\nYou are refused to cancel post!'))
        # if voucher is not in close state,refuse to cancel!               
        voucher_obj = self.pool.get('easy.voucher').browse(cr, uid, voucher_ids, context)
        for line in voucher_obj:
            if line.state not in ('book'):
                raise osv.except_osv(_('Refuse!'), _('Voucher No.' + str(line.code) + ' is not posted,\nYou are refused to cancel post!'))
        # batch cancel post
        voucher_obj = self.pool.get('easy.voucher')
        voucher_obj.write(cr, uid, voucher_ids, {'state':'approve', 'postpsn':None}, context)
        return
    
    def voucher_batch_post(self, cr, uid, ids, context=None):
        voucher_ids = self._get_voucher_ids_for_batch(cr, uid, ids, context)
        # get accounting period line ids
        period_line = self.pool.get('easy.voucher').read(cr, uid, voucher_ids, ['period_line_id'], context)
        period_line_ids = []
        for i in period_line:
            period_line_ids.append(i['period_line_id'][0])
        period_line = self.pool.get('easy.period.line').browse(cr, uid, period_line_ids, context)
        # if period has been closed ,refuse to cancel!
        for i in period_line:
            if i.state == 'close':
                raise osv.except_osv(_('Refuse!'), _(str(i.period_start) + '~' + str(i.period_end) + ' has been closed,\nYou are refused to cancel post!'))
        # if voucher is not in close state,refuse to cancel!               
        voucher_obj = self.pool.get('easy.voucher').browse(cr, uid, voucher_ids, context)
        for line in voucher_obj:
            if line.state not in ('approve'):
                raise osv.except_osv(_('Refuse!'), _('Voucher No.' + str(line.code) + ' is not approved,\nYou are refused to post!'))
        # batch cancel post
        voucher_obj = self.pool.get('easy.voucher')
        voucher_obj.write(cr, uid, voucher_ids, {'state':'book', 'postpsn':self._get_maker(cr, uid, ids, context)}, context)
        return
    
    def voucher_batch_approve(self, cr, uid, ids, context=None):
        voucher_ids = self._get_voucher_ids_for_batch(cr, uid, ids, context)
        # get accounting period line ids
        period_line = self.pool.get('easy.voucher').read(cr, uid, voucher_ids, ['period_line_id'], context)
        period_line_ids = []
        for i in period_line:
            period_line_ids.append(i['period_line_id'][0])
        period_line = self.pool.get('easy.period.line').browse(cr, uid, period_line_ids, context)
        # if period has been closed ,refuse to cancel!
        for i in period_line:
            if i.state == 'close':
                raise osv.except_osv(_('Refuse!'), _(str(i.period_start) + '~' + str(i.period_end) + ' has been closed,\nYou are refused to cancel post!'))
        # if voucher is not in close state,refuse to cancel!               
        voucher_obj = self.pool.get('easy.voucher').browse(cr, uid, voucher_ids, context)
        for line in voucher_obj:
            if line.state not in ('make'):
                raise osv.except_osv(_('Refuse!'), _('Voucher No.' + str(line.code) + ' is not in making status,\nYou are refused to approve!'))
        # batch cancel post
        voucher_obj = self.pool.get('easy.voucher')
        voucher_obj.write(cr, uid, voucher_ids, {'state':'approve', 'approver':self._get_maker(cr, uid, ids, context)}, context)
        return
    def voucher_batch_cancel_approve(self, cr, uid, ids, context=None):
        voucher_ids = self._get_voucher_ids_for_batch(cr, uid, ids, context)
        # get accounting period line ids
        period_line = self.pool.get('easy.voucher').read(cr, uid, voucher_ids, ['period_line_id'], context)
        period_line_ids = []
        for i in period_line:
            period_line_ids.append(i['period_line_id'][0])
        period_line = self.pool.get('easy.period.line').browse(cr, uid, period_line_ids, context)
        # if period has been closed ,refuse to cancel!
        for i in period_line:
            if i.state == 'close':
                raise osv.except_osv(_('Refuse!'), _(str(i.period_start) + '~' + str(i.period_end) + ' has been closed,\nYou are refused to cancel post!'))
        # if voucher is not in close state,refuse to cancel!               
        voucher_obj = self.pool.get('easy.voucher').browse(cr, uid, voucher_ids, context)
        for line in voucher_obj:
            if line.state not in ('approve'):
                raise osv.except_osv(_('Refuse!'), _('Voucher No.' + str(line.code) + ' is not approved,\nYou are refused to cancel approve!'))
        # batch cancel post
        voucher_obj = self.pool.get('easy.voucher')
        voucher_obj.write(cr, uid, voucher_ids, {'state':'make', 'approver':None}, context)
        return

AccountVoucherBatchOperation()

class AccountsView(osv.Model):
    _name = "easy.accounts.view"
    _auto = False
    _columns = {
              'acc_code':fields.char(size=120, string=u"Account Code"),
              'acc_name':fields.char(size=120, string=u"Account Name"),
              'root_code':fields.char(size=120, string=u"Account Root Code"),
              'root_id':fields.integer(u"Account Root ID"),
              'lv':fields.integer(u"Levels"),
              }
    _order = "root_id", "acc_code"
    
    def init(self, cr):
        tools.sql.drop_view_if_exists(cr, 'easy_accounts_view')
        cr.execute("""
        drop view if exists easy_accounts_view;
        create or replace view easy_accounts_view as
        with recursive info(acc_id,pid,acc_code,acc_name,root_code,root_id,lv) as (
        select id acc_id,parent_id pid,code acc_code,show_name acc_name,code root_code,id root_id,1 lv 
        from easy_accounts where is_default_entity=True
        union all
        select id,parent_id,code,show_name,info.root_code,info.root_id,info.lv+1 
        from easy_accounts acct 
        inner join info on acct.id=info.pid
        where acct.is_default_entity=True
        )
        select acc_id id,acc_code,acc_name,root_code,root_id,lv from info
        order by root_code,acc_code;
        """)
AccountsView()


class AccoutsExecuteSQL(osv.Model):
    
    _name = 'easy.execute.sql'
    _auto = False
    _columns = {
              'sql':fields.char(size=1),
              }
    
    def init(self, cr):
        tools.sql.drop_view_if_exists(cr, 'easy_accounts_view_forvoucher')
        cr.execute("""
        drop function if exists modify_period() cascade;
        create or replace FUNCTION modify_period()
        returns TRIGGER
        AS
        $$
        DECLARE
          bookdate date;
        BEGIN
          select date_start_book into bookdate from easy_entity where id=(
                select entity_id from easy_period where id=NEW.period_id);
            if to_char(extract(year from bookdate),'9999')||lpad(trim(both ' ' from (to_char(extract(month from bookdate),'99'))),2,'0')>to_char(extract(year from new.period_start),'9999')||lpad(trim(both ' ' from (to_char(extract(month from new.period_start),'99'))),2,'0') THEN
              new.isactive=FALSE;
              new.state='close';
          end if;
          return new;
        end;
        $$
        language plpgsql;
        drop trigger if exists modify_period_when_create on easy_period_line;
        create trigger modify_period_when_create before insert on easy_period_line
        for each row execute procedure modify_period();
        drop view if exists easy_accounts_balance_for_period;
        create or replace view easy_accounts_balance_for_period
        as
        with info as(
                select vou.period_line_id,line.account_id,sum(debit_amount) debit,sum(credit_amount) credit
                from easy_voucher_line line
                inner join easy_voucher vou on line.voucher_id=vou.id
                where vou.is_default_entity=True
                group by vou.period_line_id,line.account_id)
                select info.period_line_id,info.account_id,debit,credit,
                case acc.direction when 'debit' then coalesce(debit,0)-COALESCE(credit,0)
                else -COALESCE(debit,0)+COALESCE(credit,0) end balance
                from info
                inner join easy_accounts acc on acc.id=info.account_id;
        """
        )

AccoutsExecuteSQL()
