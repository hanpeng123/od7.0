# -*- coding:utf-8 -*-
from openerp.osv import osv, fields
import time
import datetime
from openerp import tools

class AccTools():
    
    # 这个函数是将字符串日期转换成DATE类型，此处要评估时间的字符串格式是否为年-月-日格式，才能在生产环境发布
    def get_date_from_string(self, datestring):
        date_info = time.strptime(datestring, "%Y-%m-%d")
        y = date_info[0]
        m = date_info[1]
        d = date_info[2]
        return datetime.date(y, m, d)
    
    def date_addamonth(self, dt):
        y = dt.year
        m = dt.month + 1
        if m > 12:
            y += 1
            m = 1
        return datetime.date(y, m, 1)
    
    def days_of_month(self, year, month):
        dayslist = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
            dayslist[1] = 29
        return datetime.date(year, month, dayslist[month - 1])
    
    def months_period(self, d_start, d_end):
        res = []
        i = 0
        while(d_start <= d_end):
            first_day = d_start
            last_day = self.days_of_month(d_start.year, d_start.month)
            if last_day > d_end:
                last_day = d_end
            curr = (first_day, last_day)
            res.append(curr)
            d_start = self.date_addamonth(d_start)
        return res
    
    def get_current_year_day(self, symble):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        # #
        if symble == 0:
            ticks = str(ticks) + '-01' + '-01'
        elif symble == 1:
            ticks = str(ticks) + '-12' + '-31'
        return ticks
    
    def get_current_year(self):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        return ticks
    
    def get_current_datetime(self):
        ticks = time.localtime(time.time())
        return str(ticks[0]) + '-' + str(ticks[1]) + '-' + str(ticks[2]) + ' ' + str(ticks[3]) + ':' + str(ticks[4]) + ':' + str(ticks[5])


class AccountEntity(osv.Model):
    
    actools = AccTools()
    
    _first_day_of_year = actools.get_current_year_day(0)
    _last_day_of_year = actools.get_current_year_day(1)
    
    def _get_default_current_datetime(self, cr, uid, ids, context=None):
        actools = AccTools()
        return actools.get_current_datetime()
    
    
    _name = 'easy.entity'
    _columns = {
              'code':fields.char(size=20, required=True, string=u"Entity Code"),
              'name':fields.char(size=100, required=True, string=u"Entity Name"),
              'period_ids':fields.one2many('easy.period', 'entity_id', u"Period IDs"),
              'acc_patten_ids':fields.one2many('easy.account.patten', 'entity_id', u"Accounts Patten IDs"),
              'year_start':fields.date(required=True, string=u"Financial Year Start", readonly=False, states={'open': [('readonly', True)]}),
              'year_end':fields.date(required=True, string=u"Financial Year End", readonly=False, states={'open': [('readonly', True)]}),
              'vat_scale':fields.selection([('small', u"Small"), ('general', u"General"), ], string=u"Entity Type", required=True, readonly=False, states={'open': [('readonly', True)]}),
              'isactive':fields.boolean(u"Active"),
              'remark':fields.text(u"Remark"),
              'state': fields.selection([('edit', 'Editing'), ('open', 'Open'), ('closed', 'Closed'), ], 'Status', readonly=True),
              'default_entity':fields.boolean(u"Default Entity", readonly=True),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
              'isactive':True,
              'year_start':_first_day_of_year,
              'year_end':_last_day_of_year,
              'vat_scale':'small',
              'state':'edit',
              'default_entity':True,
              'ts':_get_default_current_datetime,
              }
    _sql_constraints = [
                      ('unique_entity_code', 'unique(code)', 'Entity code must be unique!'),
                      ('unique_entity_name', 'unique(name)', 'Entity name must be unique!'),
                      ('start_gt_end', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ]
    
    def create(self, cr, uid, vals, context=None):
        # 修改会计主体的状态
        vals['state'] = 'open'
        # 向会计期间主表写入数据
        if vals['year_start'] and vals['year_end']:
            res = []
            periods = []
            periods.append(0)
            periods.append(False)
            periods.append({'year_start':vals['year_start'], 'year_end':vals['year_end'], })
            res.append(periods)
            vals['period_ids'] = res
        # 向会计科目位数表（easy.account.patten）表写入数据
        res = []
        acc_patten = []
        acc_patten.append(0)
        acc_patten.append(False)
        acc_patten.append({'acc_patten':'42222', 'is_default':True, })
        res.append(acc_patten)
        vals['acc_patten_ids'] = res
        # Set all entities as non-default entities.
        cr.execute("update easy_entity set default_entity=False;")
        return super(AccountEntity, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if vals['isactive']:
            vals['state'] = 'open'
        else:
            vals['state'] = 'closed'
        return super(AccountEntity, self).write(cr, uid, ids, vals, context=context)
    
    def send_as_default_entity(self, cr, uid, ids, context=None):
        cr.execute("update easy_entity set default_entity=False where id!=%d" % (ids[0]));
        cr.execute("update easy_entity set default_entity=True where id=%d" % (ids[0]))
        # update all accounts
        cr.execute("update easy_accounts set is_default_entity=False where entity_id!=%d" % (ids[0],))
        cr.execute("update easy_accounts set is_default_entity=True where entity_id=%d" % (ids[0],))
        # update all accounts-patten
        cr.execute("update easy_account_patten set is_default=False where entity_id!=%d" % (ids[0],))
        cr.execute("update easy_account_patten set is_default=True where entity_id=%d" % (ids[0],))
        # update all vouchers
        cr.execute("update easy_voucher set is_default_entity=False")
        cr.execute("""update easy_voucher set is_default_entity=True where id in(
            select id from easy_voucher
            where period_line_id in (
            select line.id from easy_period_line line
            inner join easy_period per on line.period_id=per.id
            inner join easy_entity ent on per.entity_id=ent.id
            where ent.id=%d
            ));""" % (ids[0],))
        # return self.write(cr, uid, ids, {'default_entity':True}, context),此处vals为何只有｛‘default_entity’｝一个键值对？？？
        return True
    
AccountEntity()

class AccountsPeriod(osv.Model):
    
    actools = AccTools()
    _current_ts = actools.get_current_datetime()
    
    _name = 'easy.period'
    _auto = True
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity ID", required=True, ondelete='restrict'),
              'year_start':fields.date(u"Year Start", required=True),
              'year_end':fields.date(u"Year End", required=True),
              'line_ids':fields.one2many('easy.period.line', 'period_id', u"Line IDs"),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
               'ts':_current_ts,
               }
    _sql_constraints = [
                      ('start_gt_end_period', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ('unique_period', 'unique(entity_id,year_start,year_end)', 'Year start and year end must be unique per accounting period!'),
                      ]
    _sql = """create or replace view hanpeng_view_test
      as
      select * from easy_period
    """
    def create(self, cr, uid, vals, context=None):
        if vals['year_start'] and vals['year_end']:
            res = []
            actools = AccTools()
            y_s = actools.get_date_from_string(vals['year_start'])
            y_e = actools.get_date_from_string(vals['year_end'])
            months = actools.months_period(y_s, y_e)
            for i in range(len(months)):
                periods = []
                periods.append(0)
                periods.append(False)
                periods.append({'period_start':months[i][0], 'period_end':months[i][1], })
                res.append(periods)
            vals['line_ids'] = res
        return super(AccountsPeriod, self).create(cr, uid, vals, context=context)
       
AccountsPeriod()

class AccountsPeriodLine(osv.Model):
    
    _name = 'easy.period.line'
    _columns = {
              'period_id':fields.many2one('easy.period', string=u"Period ID", required=True, ondelete='restrict'),
              'period_start':fields.date(string=u"Accounting Period Start", required=True),
              'period_end':fields.date(string=u"Accounting Period End", required=True),
              'isactive':fields.boolean(u"Active"),
              }
    _defaults = {
               'isactive':True,
               }
    _sql_constraints = [
                      ('unique_year_month_per_period', 'unique(period_id,period_start,period_end)', 'Accounting Year-month must be unique per period.'),
                      ]
    
    def name_get(self, cr, uid, ids, context=None):
        if not ids:
            return []
        if isinstance(ids, (int, long)):
                    ids = [ids]
        reads = self.read(cr, uid, ids, ['period_start', 'period_end'], context=context)
        res = []
        for record in reads:
            name = record['period_start'] + ' ~ ' + record['period_end']
            res.append((record['id'], name))
        return res
AccountsPeriodLine()


class AccountsPatten(osv.Model):
    
    _name = 'easy.account.patten'
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity ID", required=True),
              'acc_patten':fields.char(size=20, required=True, string=u"Accounts code Patten"),
              'is_default':fields.boolean(u"Is a default entity?"),
              }    
    _sql_constraints = [
                      ('unique_accode_patten', 'unique(entity_id,acc_patten)', 'Accounts code patten must be unique!'),
                      ('account_patten', "check(acc_patten similar to '\d+')", 'Accounts code does not match code patten!'),
                      ]
    _defaults = {
               'acc_patten':'42222',
               'is_default':True,
               }
    
class Accounts(osv.Model):
    
    def _get_default_entity(self, cr, uid, ids, context=None):
        # 返回值是eids[0],是标量值，如果是eids，则是列表格式，保存时会出错。
        entity = self.pool.get('easy.entity')
        eids = entity.search(cr, uid, [('default_entity', '=', True), ], context)
        if not eids:
            return []
        return eids[0]
    
    def _get_account_patten_running(self, cr, uid, ids, fields, args, context=None):
        res = {}
        # 获取当前会计科目对应的会计主体ID
#         entity=self.pool.get('easy.entity')
#         eids=entity.search(cr,uid,[('default_entity','=',True),],context)
        sql_str = """
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result = cr.dictfetchone()
        if result and result['acc_patten']:
            res[ids[0]] = result['acc_patten']
        return res
    
    def _get_account_patten_designing(self, cr, uid, ids, context=None):
        sql_str = """
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result = cr.dictfetchone()
        if result and result['acc_patten']:
            return result['acc_patten']
        return

        
    
    def _get_account_depth(self, cr, uid, ids, fields, args, context=None):
        res = {}
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select aid,acode,aname,adepth from info
            order by adepth desc;          
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchall()
            if sql_res:
                res[ids[0]] = ""
                for line in sql_res:
                    res[ids[0]] += line['acode'] + ' ' + line['aname'] + '>'
            else:
                res[ids[0]] = "None"
        return res
    
    def _get_account_depthnum(self, cr, uid, ids, context=None):
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select max(adepth) max_depth from info;
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchone()
            if sql_res:
                return sql_res['max_depth']
            else:
                return 0
        return
    
    def _check_account_code(self, cr, uid, ids, context=None):
        # 检查会计科目的位数与ACCOUNT_PATTEN定义的是否一致
        acc_patten = self._get_account_patten_designing(cr, uid, ids, context=None)
        obj = self.browse(cr, uid, ids[0], context=context)
        if (not obj.parent_id) and len(obj.code) != int(acc_patten[0]):
            return False
        if obj.parent_id:
            max_level = self._get_account_depthnum(cr, uid, ids, context)
            current_length = 0
            for i in range(max_level):
                current_length += int(acc_patten[i])
            if current_length != len(obj.code):
                return False
        return True
    
    def _check_account_code_match_parent(self, cr, uid, ids, context=None):
        # 检查子科目与上级科目之间的编码前几位是否相同
        sub_account = self.browse(cr, uid, ids[0], context)
        if sub_account.parent_id:
            parent_account = self.read(cr, uid, sub_account.parent_id.id, ['code'], context)
            parent_account_code = parent_account['code']
            sub_account_code = sub_account.code[0:len(parent_account_code)]
            if sub_account_code != parent_account_code:
                return False        
        return True
    
#     def _entity_is_default(self,cr,uid,ids,context=None):
#         result={}
#         sql_str="""
#         select default_entity from easy_entity where id=(
#         select entity_id from easy_accounts where id=%d);
#         """%(ids[0],)
#         cr.execute(sql_str)
#         res=cr.dictfetchone()
#         if res and res['default_entity']:
#             return {ids[0]:res['default_entity']}
#         return result

    _name = 'easy.accounts'
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Accounting Entity", required=True, readonly=True),
              'code':fields.char(size=100, required=True, string=u"Account Code"),
              'show_name':fields.char(size=100, required=True, string=u"Account Name"),
              'name':fields.char(size=120, readonly=True, string=u"Account Full Name"),
              'parent_id':fields.many2one('easy.accounts', u"Parent Account", domain=[('is_default_entity', '=', True)]),
              'child_ids':fields.one2many('easy.accounts', 'parent_id', u'Direct Children Accounts:', readonly=True),
              'direction':fields.selection([('debit', u"Debit"), ('credit', u'Credit'), ], u"Balance Direction", required=True),
              'classification':fields.selection([('asset', u'Asset'),
                                                 ('liability', u"Liability"),
                                                 ('ownership', u"Owner's Equity"),
                                                 ('income', u"Income"),
                                                 ('expense', u'Expense'),
                                                 ], u"Classification", required=True),
              'is_default_entity':fields.boolean(string=u"Is Default Entity?"),
              'account_patten':fields.function(_get_account_patten_running, type='char', string=u"Account Patten"),
              'account_patten2':fields.char(size=100, string=u"Account Patten", readonly=True),
              'account_depth':fields.function(_get_account_depth, type='char', string=u"Account Depth"),
              'isactive':fields.boolean(u"Active", readonly=True),
              'type':fields.selection([('view', u'View'), ('comm', u'Common')], string=u'Type', required=True),
              'remark':fields.text(u"Remark:"),
              'state':fields.selection([('edit', u"Editing"), ('confirm', u"Confirmed"), ('close', u"Closed")], u"Status", required=True, readonly=True)     
              }
    _defaults = {
               'isactive':True,
               'entity_id':_get_default_entity,
               'account_patten2':_get_account_patten_designing,
               'is_default_entity':True,
               'state':'edit',
               'type':'comm',
               }
    _sql_constraints = [
                      ('unique_chart_code', 'unique(entity_id,code)', 'Account code must be unique in an accounting entity!'),
                      ('check_account_code', "check(code similar to '\d+')", 'Account code must be digits!'),
                      ]
    _constraints = [
                  (_check_account_code, 'Account code length does not match the account patten!', ['Account Code']),
                  (_check_account_code_match_parent, 'Account code must match the parent code', ['Acccount Code']),
                  ]
    def _set_accounts_type_onwrite(self, cr, uid, ids, context=None):
        # check if current account's parent account has children accounts except current account.
        # if has no more children accounts,update it as common.
        sql_str = """
        update easy_accounts set type='comm' where id=(
        select parent_id from easy_accounts where id=%d
        ) and 0=(select count(id) cid from easy_accounts where parent_id=(
        select parent_id from easy_accounts where id=%d)
        and id !=%d);
        """ % (ids[0], ids[0], ids[0],)
        cr.execute(sql_str)
        return
    
    def write(self, cr, uid, ids, vals, context=None):
        code = ""
        show_name = ""
        sql_str = """
            select code,show_name from easy_accounts where id=%d
            """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['code'] and res['show_name']:
            code = res['code']
            show_name = res['show_name']
        
        if 'code' in vals.keys():
            code = vals['code']
        if 'show_name' in vals.keys():
            show_name = vals['show_name']
        vals['name'] = code + ' ' + show_name
        # update parent account's type
        self._set_accounts_type_onwrite(cr, uid, ids, context)
        if 'parent_id' in vals.keys() and vals['parent_id']:
            sql_str = """
            update easy_accounts set type='view' where id=%d and type='comm';
            """ % (vals['parent_id'],)
            cr.execute(sql_str)
        #
        return super(Accounts, self).write(cr, uid, ids, vals, context=context)
    
    def create(self, cr, uid, vals, context=None):
        vals['name'] = vals['code'] + ' ' + vals['show_name']
        vals['state'] = 'confirm'
        # if it has parent account,then update its parent type as view
        if vals['parent_id']:
            sql_str = """
            update easy_accounts set type='comm' where id=%d and type!='comm';
            """ % (vals['parent_id'],)
            cr.execute(sql_str)
        #
        return super(Accounts, self).create(cr, uid, vals, context=context)
    
    def set_account_code_from_parent(self, cr, uid, ids, parent_id, context):
        # 根据父项科目，自动生成下级科目 编码
        # 得到科目的位数级次定义
        # 先不做，这个功能未必实用
        # acc_patten=self._get_account_patten_designing(cr,uid,ids,context)
        return
    
    def onchange_parent_id(self, cr, uid, ids, parent_id, context=None):
        val = {'direction':None, 'classification':None, 'code':None, 'child_ids':None, 'child_ids':[]}
               
        # 得到目前会计科目的余额方向和类型
        if parent_id:
            parent_info = self.browse(cr, uid, parent_id, context)
            # 取出父项科目的直属下级科目
            children = []
            obj = self.search(cr, uid, [('parent_id', '=', parent_id), ], context)
            if obj:
                children = obj
            val = {'direction':parent_info.direction, 'classification':parent_info.classification, 'code':parent_info.code, 'child_ids':children}
        return {'value':val}
    
#     def set_account_as_confirm(self,cr,uid,ids,context=None):
#         return self.write(cr, uid, ids, {'state': 'confirm','isactive':True}, context=context)
    
    def get_children_accounts(self, cr, uid, ids, context=None):
        account_list = "Current account and all its children accounts(as follows)"
        account_list += '\n' + "will be closed. All closed accounts will "
        account_list += '\n' + "never occur in voucher making but can be queried in history voucher."
        account_list += '\n' + "If you want to reopen these closed accounts,"
        account_list += '\n' + "you must reopen them by one by,there is no batch-reopen operation for you.\n"
        sql_str = """
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.aid=easy_accounts.parent_id
            )
            select aid,aname,adepth,state from info where state not in ('close')
            order by adepth;
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchall()
        if res and len(res) > 1:
            for info in res:
                account_list += '\nX ' + info['aname'] + ', current state:' + info['state']
        elif res and len(res) == 1:
            account_list = "N"
        return account_list
    
    def get_parent_accounts(self, cr, uid, ids, context=None):
        account_list = "Current account and all its parent accounts(as follows)"
        account_list += '\n' + "will be reopen. Would you continue?"
        sql_str = """
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select aid,aname,adepth,state from info where state not in ('confirm')
            order by adepth desc;
        """ % (ids[0],)
        cr.execute(sql_str)
        res = cr.dictfetchall()
        if res and len(res) > 1:
            for info in res:
                account_list += '\nX ' + info['aname'] + ', current state:' + info['state']
        elif res and len(res) == 1:
            account_list = "N"
        return account_list
    
    def set_account_as_closed(self, cr, uid, ids, context=None):
        children_accounts_num = len(self.get_children_accounts(cr, uid, ids, context))
        # 如果返回值为1，则表示只有当前科目而无下级科目需要更新。
        if children_accounts_num == 1:
            return self.write(cr, uid, ids, {'state': 'close', 'isactive':False}, context=context)
        p_obj = self.browse(cr, uid, ids[0], context)
        ir_model_data = self.pool.get('ir.model.data')
        compose_form_id = ir_model_data.get_object_reference(cr, uid, 'easybook', 'close_account_form_view')[1]
        ctx = dict(context)
        ctx.update({
            'default_user_id':uid,
            'default_account_id':ids[0],
            'default_desc':self.get_children_accounts(cr, uid, ids, context),
        })    
        return {
            'name':'Close Accounts',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'easy.closeaccount.log',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'nodestroy': True,
            'target': 'new',
            'context': ctx,
        }
        
    def set_account_as_confirm(self, cr, uid, ids, context=None):
        parent_accounts_num = len(self.get_parent_accounts(cr, uid, ids, context))
        # 如果返回为1，则表示当前科目封存父项科目。
        if parent_accounts_num == 1:
            return self.write(cr, uid, ids, {'state': 'confirm', 'isactive':True}, context=context)
        p_obj = self.browse(cr, uid, ids[0], context)
        ir_model_data = self.pool.get('ir.model.data')
        compose_form_id = ir_model_data.get_object_reference(cr, uid, 'easybook', 'reopen_account_form_view')[1]
        ctx = dict(context)
        ctx.update({
            'default_user_id':uid,
            'default_account_id':ids[0],
            'default_desc':self.get_parent_accounts(cr, uid, ids, context),
        })    
        return {
            'name':'Close Accounts',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'easy.closeaccount.log',
            'views': [(compose_form_id, 'form')],
            'view_id': compose_form_id,
            'nodestroy': True,
            'target': 'new',
            'context': ctx,
        }
        
Accounts()


class CloseAccountLog(osv.Model):
    
    _name = 'easy.closeaccount.log'
    _columns = {
              'account_id':fields.integer(u"Account ID"),
              'user_id':fields.integer(u"User"),
              'desc':fields.text(u"Description", readonly=True),
              }
    
    def close_accounts(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        sql_str = """
            update easy_accounts set (state,isactive)=('close',False)
            where id in (
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts on info.aid=easy_accounts.parent_id
            )
            select aid from info where state not in ('close'));
        """ % (obj.account_id,)
        cr.execute(sql_str)
        return {'type': 'ir.actions.act_window_close'}
    
    def reopen_accounts(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        sql_str = """
            update easy_accounts set (state,isactive)=('confirm',True)
            where id in (
            with RECURSIVE info(aid,aname,parent_id,adepth,state) as(
            select id aid,name aname,parent_id,1 adepth,state from easy_accounts where id =%d
            union ALL
            select id,name,easy_accounts.parent_id,adepth+1,easy_accounts.state from info inner join easy_accounts 
                        on info.parent_id=easy_accounts.id
            )
            select aid from info where state not in ('confirm'));
        """ % (obj.account_id,)
        cr.execute(sql_str)
        return {'type': 'ir.actions.act_window_close'}

CloseAccountLog()


class AccountVoucher(osv.Model):
    
    def _get_default_period_line(self, cr, uid, ids, context=None):
        sql_str = """
        select min(line.id) mid
        from easy_period_line line
        inner join easy_period period on line.period_id=period.id
        inner join easy_entity entity on period.entity_id=entity.id
        where entity.default_entity=True;
        """
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['mid']:
            return res['mid']
        return False
    
    def _get_maker(self, cr, uid, ids, context=None):
        sql_str = """
            select id from res_partner where id=(
            select partner_id from res_users where id=%d
            )
            """ % (uid,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res and res['id']:
            return res['id']
        return None
    
    def _get_voucher_sn(self, cr, uid, ids, context=None):
        voucher_sn = 1
        period_line_id = self._get_default_period_line(cr, uid, ids, context)
        if period_line_id:
            sql_str = """
            select max(vou.code) id_num from easy_voucher vou
            inner join easy_period_line line on vou.period_line_id=line.id
            inner join easy_period per on line.period_id=per.id
            inner join easy_entity ent on per.entity_id=ent.id
            where ent.default_entity=True and line.id=%d
            """ % (period_line_id,)
            cr.execute(sql_str)
            res = cr.dictfetchone()
            if res and res['id_num']:
                voucher_sn = res['id_num'] + 1
        return voucher_sn
    
        
    def _get_default_voucher_date(self, cr, uid, ids, context=None):
        period_line_id = self._get_default_period_line(cr, uid, ids, context)
        ticks = time.localtime(time.time())
        default_voucher_date = str(ticks[0]) + '-' + str(ticks[1]).rjust(2, '0') + '-' + str(ticks[2]).rjust(2, '0')
        sql_str = """
         select 
            extract(year from period_start) yy,
            extract(month from period_start) mm
            from easy_period_line
         where id=%d
         """ % (period_line_id,)
        cr.execute(sql_str)
        res = cr.dictfetchone()
        if res:
            default_voucher_date = str(int(res['yy'])) + '-' + str(int(res['mm'])).rjust(2, '0') + '-' + str(ticks[2]).rjust(2, '0')
        return default_voucher_date
    
    def _check_voucherdate(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        DATETIME_FORMAT = "%Y-%m-%d"
        voucherdate = datetime.datetime.strptime(obj.voucher_date, DATETIME_FORMAT)
        v_yy = voucherdate.year
        v_mm = voucherdate.month
        p_date = self._get_default_voucher_date(cr, uid, ids, context)
        p_date = datetime.datetime.strptime(p_date, DATETIME_FORMAT)
        p_yy = p_date.year
        p_mm = p_date.month
        if v_yy == p_yy and v_mm == p_mm:
            return True
        return False
        
    _name = 'easy.voucher'
    _columns = {
              'period_line_id':fields.many2one('easy.period.line', u"Periods", required=True, readonly=True),
              'code':fields.integer(u"Voucher Number", required=True, readonly=True),
              'voucher_date':fields.date(u"Voucher Date", required=True),
              'name':fields.text(u"Description"),
              'maker':fields.many2one('res.partner', u"Maker", required=True, readonly=True),
              'doc_num':fields.integer(u"Documents Number"),
              'voucher_line_ids':fields.one2many('easy.voucher.line', 'voucher_id', u"Voucher line"),
              'is_default_entity':fields.boolean(u'Is Default Entity?'),
              }
    _defaults = {
               'doc_num':0,
               'period_line_id':_get_default_period_line,
               'maker':_get_maker,
               'code':_get_voucher_sn,
               'is_default_entity':True,
               'voucher_date':_get_default_voucher_date,
               }
    _sql_constraints = [
                      ('unique_voucher_code', 'unique(period_line_id,code)', 'Voucher sn must be unique!'),
                      ('code_gt_zero', 'check(code>0)', 'Voucher SN must be greater than zero!'),
                      ]
    
    def _check_total_value(self, cr, uid, ids, context=None):
        debit_total=0
        credit_total=0
        obj=self.pool.get('easy.voucher.line')
        line_ids=obj.search(cr,uid,[('voucher_id','=',ids[0]),],context)
        obj=self.browse(cr, uid, line_ids,context)
        print "***********_____________"
        print "here i am."
        for line in obj:
            voucher_line=self.pool.get('easy.voucher.line').read(cr,uid,line.id,context)
            debit_total+=voucher_line['debit_amount']
            credit_total+=voucher_line['credit_amount']
        if debit_total!=credit_total:
            return False
        return True
    _constraints = [
                  (_check_voucherdate, 'Voucher date must be during in accounting period!', ['Voucher Date Error']),
                  (_check_total_value,'Unbalanced',['Value Check']),
                  ]
    
AccountVoucher()

class AccountVoucherLine(osv.Model):
    
    _name = 'easy.voucher.line'
    _columns = {
              'voucher_id':fields.many2one('easy.voucher', u"Voucher ID", required=True, ondelete='cascade'),
              'account_id':fields.many2one('easy.accounts', u"Accounts", required=True, domain=[('is_default_entity', '=', True), ('type', '=', 'comm')]),
              'description':fields.char(size=200, string=u"Description"),
              'debit_amount':fields.float(u"Debit"),
              'credit_amount':fields.float(u"Credit"),
              }
    _sql_constraints = [
                      ('check_amount', 'check(COALESCE(debit_amount,0)+COALESCE(credit_amount,0)!=0)', 'Amount must not be zero!'),
                      ]
    
    _defaults = {
               'debit_amount':None,
               'credit_amount':None,
               }
    def _check_value(self, cr, uid, ids, context=None):
        obj = self.browse(cr, uid, ids[0], context)
        if obj.debit_amount and obj.credit_amount:
            return False
        return True
    
    _constraints = [
                 (_check_value, 'debit and credit can not all have value at the same time!', ['Value Error!']),
                 ]
    

AccountVoucherLine()

class AccoutsForVoucher(osv.Model):
    
    _name = 'easy.accounts.view.forvoucher'
    _auto = False
    _columns = {
              'code':fields.char(size=100, readonly=True, string=u"Accounts Code"),
              'name':fields.char(size=220, readonly=True, string=u"Accounts Name"),
              }
    _order = 'name'
    
    def init(self, cr):
        tools.sql.drop_view_if_exists(cr, 'easy_accounts_view_forvoucher')
        cr.execute("""
        create or replace view easy_accounts_view_forvoucher as
        select id,code,name from easy_accounts where id not in (
        select parent_id from easy_accounts where parent_id is not null
        ) and entity_id in (select id from easy_entity where default_entity=True)
        """
        )

AccoutsForVoucher()
