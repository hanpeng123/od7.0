from openerp.osv import osv,fields
from openerp import tools

class TestSQL(osv.Model):
    
    _name='test.sql1'
    _columns={
              'age':fields.integer(u"Age"),
              }
    _sql="""
    create or replace view test_view1
    as
    select age from test_sql1;
    """
TestSQL()


class TestSQL2(osv.Model):
    
    _name='test.sql2'
    _columns={
              'age':fields.integer(u"Age"),
              }
    _sql="""
    drop function if exists test_func();
    create or replace function test_func()
    returns integer
    as
    $$
      select 1
    $$
    language sql;
    """
TestSQL2()

class TestSQL3(osv.Model):
    
    _name='test.sql3'
    _columns={
              'age':fields.integer(u'Age'),
              }
    _sql="""
    drop table if exists test;
    create table test
    (tid serial primary key,
    tname varchar(20) not null);
    insert into test(tname) values('hanlujia');
    """
TestSQL3()

class TestSQL5(osv.Model):
    
    _name='test.sql5'
    _columns={
              'age':fields.integer(u'Age'),
              }
    
    def init(self, cr):
        cr.execute("""
        create or replace function get_new_for_test()
        returns TRIGGER
        AS
        $$
        BEGIN
          new.tname=new.tname||'odoo is good.';
          return new;
        end;
        $$
        language plpgsql;
        """
        )

class TestSQL6(osv.Model):
    
    _name='test.sql6'
    _columns={
              'age':fields.integer(u'Age'),
              }
    
    def init(self, cr):
        cr.execute("""
        create trigger set_new_for_test before insert on test
        for each row execute procedure get_new_for_test();
        """
        )