{
    'name' : 'why sql',
    'version' : '1.0',
    'author' : 'hp',
    'category' : 'sql',
    'description' : """
    why sql
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['base'],
    'data': [
                 ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
