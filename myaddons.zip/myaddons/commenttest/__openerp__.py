{
    'name' : 'shenpi',
    'version' : '1.0',
    'author' : 'hp',
    'category' : 'test',
    'description' : """
    This is a shenpi app.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['mail'],
    'data': [
             'shenpi_view.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
