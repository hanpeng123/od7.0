{
    'name' : 'mail test',
    'version' : '1.0',
    'author' : 'hp',
    'category' : 'test',
    'description' : """
    This is a test app.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['mail'],
    'data': [
             'mail_template.xml',
             'test_view.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
