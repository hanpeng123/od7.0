from openerp.osv import osv,fields

class TestSQL(osv.Model):
    
    _name='test.sql1'
    _columns={
              'age':fields.integer(u"Age"),
              }
    _sql="""
    create or replace view test_view1
    as
    select age from test_sql1;
    """
TestSQL()


class TestSQL2(osv.Model):
    
    _name='test.sql2'
    _columns={
              'age':fields.integer(u"Age"),
              }
    _sql="""
    drop function if exists test_func();
    create or replace function test_func()
    returns integer
    as
    $$
      select 1;
    $$
    language sql;
    """
TestSQL2()