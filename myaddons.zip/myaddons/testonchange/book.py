# -*- coding:utf-8 -*-
from openerp.osv import osv,fields

class Books(osv.Model):
    
    _name="test.book"
    _columns={
              'code':fields.char(size=20,string=u"Code"),
              'name':fields.char(size=20,string=u"Name"),
              'price':fields.float(string=u"Price"),
              }
    _sql_constraints=[('unique_code','unique(code)','book code must be unuqie!'),]

Books()