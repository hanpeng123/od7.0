{
    'name' : 'book test',
    'version' : '1.0',
    'author' : 'hp',
    'category' : 'sale/invoices',
    'description' : """
    CBL International Sub invoice managements and mail reminder.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['base'],
    'data': [
             'book_view.xml',    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
