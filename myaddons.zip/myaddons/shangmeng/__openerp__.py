{
    'name' : 'shangmeng crm',
    'version' : '2.0',
    'author' : 'hp',
    'category' : 'crm',
    'description' : """
    This is a crm demo for shangmeng.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['mail'],
    'data': [
             'view/smpartner_view.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
