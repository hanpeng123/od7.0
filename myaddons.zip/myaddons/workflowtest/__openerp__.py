{
    'name' : 'amt workflow',
    'version' : '1.0',
    'author' : 'hp',
    'category' : 'test',
    'description' : """
    This is a test app.
    """,
    'website': 'http://www.openerp.com',
    'images' : [],
    'depends' : ['mail'],
    'data': [
             'wfl_view_02.xml',
             'wfl_view_01.xml',
             'test_workflow.xml',
             'test_workflow2.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}
