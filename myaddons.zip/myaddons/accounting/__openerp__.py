# -*- coding: utf-8 -*-

{
    'name' : 'Actop Accounting',
    'version' : '1.0',
    'author' : 'hanpeng',
    'category' : 'actop accounting & finance',
    'description' : "actop accounting and finance",
    'website': 'http://www.actop.com',
    'images' : [],
    'depends' : ['base'],
    'data': [
             'view/accounting_period_view.xml',
             'view/accounting_period_line_view.xml',
    ],
    'js': [
    ],
    'qweb' : [
    ],
    'css':[
    ],
    'demo': [
    ],
    'test': [
    ],
    'installable': True,
    'auto_install': False,
}