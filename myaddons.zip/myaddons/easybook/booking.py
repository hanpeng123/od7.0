# -*- coding:utf-8 -*-
from openerp.osv import osv, fields
import time
import datetime

class AccTools():
    
    # 这个函数是将字符串日期转换成DATE类型，此处要评估时间的字符串格式是否为年-月-日格式，才能在生产环境发布
    def get_date_from_string(self, datestring):
        date_info = time.strptime(datestring, "%Y-%m-%d")
        y = date_info[0]
        m = date_info[1]
        d = date_info[2]
        return datetime.date(y, m, d)
    
    def date_addamonth(self, dt):
        y = dt.year
        m = dt.month + 1
        if m > 12:
            y += 1
            m = 1
        return datetime.date(y, m, 1)
    
    def days_of_month(self, year, month):
        dayslist = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
        if (year % 4 == 0 and year % 100 != 0) or year % 400 == 0:
            dayslist[1] = 29
        return datetime.date(year, month, dayslist[month - 1])
    
    def months_period(self, d_start, d_end):
        res = []
        i = 0
        while(d_start <= d_end):
            first_day = d_start
            last_day = self.days_of_month(d_start.year, d_start.month)
            if last_day > d_end:
                last_day = d_end
            curr = (first_day, last_day)
            res.append(curr)
            d_start = self.date_addamonth(d_start)
        return res
    
    def get_current_year_day(self, symble):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        # #
        if symble == 0:
            ticks = str(ticks) + '-01' + '-01'
        elif symble == 1:
            ticks = str(ticks) + '-12' + '-31'
        return ticks
    
    def get_current_year(self):
        ticks = time.localtime(time.time())
        ticks = ticks[0]
        return ticks
    
    def get_current_datetime(self):
        ticks = time.localtime(time.time())
        return str(ticks[0]) + '-' + str(ticks[1]) + '-' + str(ticks[2]) + ' ' + str(ticks[3]) + ':' + str(ticks[4]) + ':' + str(ticks[5])


class AccountEntity(osv.Model):
    
    actools = AccTools()
    
    _first_day_of_year = actools.get_current_year_day(0)
    _last_day_of_year = actools.get_current_year_day(1)
    
    def _get_default_current_datetime(self, cr, uid, ids, context=None):
        actools = AccTools()
        return actools.get_current_datetime()
    
    
    _name = 'easy.entity'
    _columns = {
              'code':fields.char(size=20, required=True, string=u"Entity Code"),
              'name':fields.char(size=100, required=True, string=u"Entity Name"),
              'period_ids':fields.one2many('easy.period', 'entity_id', u"Period IDs"),
              'acc_patten_ids':fields.one2many('easy.account.patten','entity_id',u"Accounts Patten IDs"),
              'year_start':fields.date(required=True, string=u"Financial Year Start", readonly=False,states={'open': [('readonly', True)]}),
              'year_end':fields.date(required=True, string=u"Financial Year End",readonly=False,states={'open': [('readonly', True)]}),
              'vat_scale':fields.selection([('small', u"Small"), ('general', u"General"),], string=u"Entity Type", required=True,readonly=False,states={'open': [('readonly', True)]}),
              'active':fields.boolean(u"Active"),
              'remark':fields.text(u"Remark"),
              'state': fields.selection([('edit','Editing'),('open', 'Open'),('closed','Closed'),], 'Status', readonly=True),
              'default_entity':fields.boolean(u"Default Entity",readonly=True),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
              'active':True,
              'year_start':_first_day_of_year,
              'year_end':_last_day_of_year,
              'vat_scale':'small',
              'state':'edit',
              'default_entity':True,
              'ts':_get_default_current_datetime,
              }
    _sql_constraints = [
                      ('unique_entity_code', 'unique(entity_code)', 'Entity code must be unique!'),
                      ('unique_entity_name', 'unique(entity_name)', 'Entity name must be unique!'),
                      ('start_gt_end', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ]
    
    def create(self, cr, uid, vals, context=None):
        #修改会计主体的状态
        vals['state']='open'
        #向会计期间主表写入数据
        if vals['year_start'] and vals['year_end']:
            res = []
            periods = []
            periods.append(0)
            periods.append(False)
            periods.append({'year_start':vals['year_start'], 'year_end':vals['year_end'], })
            res.append(periods)
            vals['period_ids'] = res
        #向会计科目位数表（easy.account.patten）表写入数据
        res=[]
        acc_patten=[]
        acc_patten.append(0)
        acc_patten.append(False)
        acc_patten.append({'acc_patten':'42222','is_default':True,})
        res.append(acc_patten)
        vals['acc_patten_ids']=res
        #Set all entities as non-default entities.
        cr.execute("update easy_entity set default_entity=False;")
        return super(AccountEntity, self).create(cr, uid, vals, context=context)
    
    def write(self, cr, uid, ids, vals, context=None):
        if vals['active']:
            vals['state']='open'
        else:
            vals['state']='closed'
        return super(AccountEntity, self).write(cr, uid, ids, vals, context=context)
    
    def send_as_default_entity(self,cr,uid,ids,context=None):
        cr.execute("update easy_entity set default_entity=False where id!=%d"%(ids[0]));
        cr.execute("update easy_entity set default_entity=True where id=%d"%(ids[0]))
        #update all accounts
        cr.execute("update easy_accounts set is_default_entity=False where entity_id!=%d"%(ids[0],))
        cr.execute("update easy_accounts set is_default_entity=True where entity_id=%d"%(ids[0],))
        #update all accounts-patten
        cr.execute("update easy_account_patten set is_default=False where entity_id!=%d"%(ids[0],))
        cr.execute("update easy_account_patten set is_default=True where entity_id=%d"%(ids[0],))
        #return self.write(cr, uid, ids, {'default_entity':True}, context),此处vals为何只有｛‘default_entity’｝一个键值对？？？
        return True
    
AccountEntity()

class AccountsPeriod(osv.Model):
    
    actools = AccTools()
    _current_ts = actools.get_current_datetime()
    
    _name = 'easy.period'
    _auto = True
    _columns = {
              'entity_id':fields.many2one('easy.entity', u"Entity ID", required=True, ondelete='restrict'),
              'year_start':fields.date(u"Year Start", required=True),
              'year_end':fields.date(u"Year End", required=True),
              'line_ids':fields.one2many('easy.period.line', 'period_id', u"Line IDs"),
              'ts':fields.datetime(u"Timestamp"),
              }
    _defaults = {
               'ts':_current_ts,
               }
    _sql_constraints = [
                      ('start_gt_end_period', 'check(year_start<year_end)', 'Year start must be great than year end!'),
                      ('unique_period', 'unique(entity_id,year_start,year_end)', 'Year start and year end must be unique per accounting period!'),
                      ]
    _sql = """create or replace view hanpeng_view_test
      as
      select * from easy_period
    """
    def create(self, cr, uid, vals, context=None):
        if vals['year_start'] and vals['year_end']:
            res = []
            actools = AccTools()
            y_s = actools.get_date_from_string(vals['year_start'])
            y_e = actools.get_date_from_string(vals['year_end'])
            months = actools.months_period(y_s, y_e)
            for i in range(len(months)):
                periods = []
                periods.append(0)
                periods.append(False)
                periods.append({'period_start':months[i][0], 'period_end':months[i][1], })
                res.append(periods)
            vals['line_ids'] = res
            print res
        return super(AccountsPeriod, self).create(cr, uid, vals, context=context)
       
AccountsPeriod()

class AccountsPeriodLine(osv.Model):
    
    _name = 'easy.period.line'
    _columns = {
              'period_id':fields.many2one('easy.period', string=u"Period ID", required=True, ondelete='restrict'),
              'period_start':fields.date(string=u"Accounting Period Start", required=True),
              'period_end':fields.date(string=u"Accounting Period End", required=True),
              'active':fields.boolean(u"Active"),
              }
    _defaults = {
               'active':False,
               }
    _sql_constraints = [
                      ('unique_year_month_per_period', 'unique(period_id,fy_period)', 'Accounting Year-month must be unique per period.'),
                      ]
AccountsPeriodLine()


class AccountsPatten(osv.Model):
    
    _name='easy.account.patten'
    _columns={
              'entity_id':fields.many2one('easy.entity',u"Entity ID",required=True),
              'acc_patten':fields.char(size=20,required=True,string=u"Accounts code Patten"),
              'is_default':fields.boolean(u"Is a default entity?"),
              }    
    _sql_constraints=[
                      ('unique_accode_patten','unique(entity_id,acc_patten)','Accounts code patten must be unique!'),
                      ('account_patten',"check(acc_patten similar to '\d+')",'Accounts code does not match code patten!'),
                      ]
    _defaults={
               'acc_patten':'42222',
               'is_default':True,
               }
    
class Accounts(osv.Model):
    
    def _get_default_entity(self,cr,uid,ids,context=None):
        #返回值是eids[0],是标量值，如果是eids，则是列表格式，保存时会出错。
        entity=self.pool.get('easy.entity')
        eids=entity.search(cr,uid,[('default_entity','=',True),],context)
        if not eids:
            return []
        return eids[0]
    
    def _get_account_patten_running(self,cr,uid,ids,fields,args,context=None):
        res={}
        #获取当前会计科目对应的会计主体ID
#         entity=self.pool.get('easy.entity')
#         eids=entity.search(cr,uid,[('default_entity','=',True),],context)
        sql_str="""
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result=cr.dictfetchone()
        if result and result['acc_patten']:
            res[ids[0]]=result['acc_patten']
        return res
    
    def _get_account_patten_designing(self,cr,uid,ids,context=None):
        sql_str="""
        select acc_patten from easy_account_patten where entity_id in (
        select id from easy_entity where default_entity=True);        
        """
        cr.execute(sql_str)
        result=cr.dictfetchone()
        if result and result['acc_patten']:
            return result['acc_patten']
        return

        
    
    def _get_account_depth(self, cr, uid, ids, fields, args, context=None):
        res = {}
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select aid,acode,aname,adepth from info
            order by adepth desc;          
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchall()
            if sql_res:
                res[ids[0]] = ""
                for line in sql_res:
                    res[ids[0]] += line['acode']+' '+line['aname'] + '>'
            else:
                res[ids[0]] = "None"
        return res
    
    def _get_account_depthnum(self, cr, uid, ids, context=None):
        if not ids:
            return False
        for i in ids:
            sql_res = """
            with RECURSIVE info(aid,acode,aname,parent_id,adepth) as(
            select id aid,code acode,show_name aname,parent_id,1 adepth from easy_accounts where id =%d
            union ALL
            select id,code,show_name,easy_accounts.parent_id,adepth+1 from info inner join easy_accounts on info.parent_id=easy_accounts.id
            )
            select max(adepth) max_depth from info;
            """ % (i,)
            cr.execute(sql_res)
            sql_res = cr.dictfetchone()
            if sql_res:
                return sql_res['max_depth']
            else:
                return 0
        return
    
    def _check_account_code(self,cr,uid,ids,context=None):
        
        acc_patten=self._get_account_patten_designing(cr,uid,ids,context=None)
        obj = self.browse(cr, uid, ids[0], context=context)
        if (not obj.parent_id) and len(obj.code)!=int(acc_patten[0]):
            return False
        if obj.parent_id:
            max_level=self._get_account_depthnum(cr, uid, ids, context)
            current_length=0
            for i in range(max_level):
                current_length+=int(acc_patten[i])
            print current_length
            if current_length!=len(obj.code):
                return False
        return True
    

    _name='easy.accounts'
    _columns={
              'entity_id':fields.many2one('easy.entity',u"Accounting Entity",required=True,readonly=True),
              'code':fields.char(size=100,required=True,string=u"Account Code"),
              'show_name':fields.char(size=100,required=True,string=u"Account Name"),
              'name':fields.char(size=120,readonly=True,string=u"Account Full Name"),
              'parent_id':fields.many2one('easy.accounts',u"Parent Account",domain=[('is_default_entity','=',True)]),
              'direction':fields.selection([('debit',u"Debit"),('credit',u'Credit'),],u"Balance Direction",required=True),
              'classification':fields.selection([('asset',u'Asset'),
                                                 ('liability',u"Liability"),
                                                 ('ownership',u"Owner's Equity"),
                                                 ('income',u"Income"),
                                                 ('expense',u'Expense'),
                                                 ],u"Classification",required=True),
              'is_default_entity':fields.boolean(string=u"Is Default Entity?"),
              'account_patten':fields.function(_get_account_patten_running,type='char',string=u"Account Patten"),
              'account_patten2':fields.char(size=100,string=u"Account Patten",readonly=True),
              'account_depth':fields.function(_get_account_depth,type='char',string=u"Account Depth"),
              'active':fields.boolean(u"Active"),   
              'remark':fields.text(u"Remark"),          
              }
    _defaults={
               'active':True,
               'entity_id':_get_default_entity,
               'account_patten2':_get_account_patten_designing,
               'is_default_entity':True,
               }
    _sql_constraints=[
                      ('unique_chart_code','unique(entity_id,code)','Account code must be unique in an accounting entity!'),
                      ('check_account_code',"check(code similar to '\d+')",'Account code must be digits!'),
                      ]
    _constraints=[
                  (_check_account_code,'Account code length does not match the account patten!',['Account Code']),
                  ]
    
    def write(self, cr, uid, ids, vals, context=None):
        code=""
        show_name=""
        sql_str="""
            select code,show_name from easy_accounts where id=%d
            """%(ids[0],)
        cr.execute(sql_str)
        res=cr.dictfetchone()
        if res and res['code'] and res['show_name']:
            code=res['code']
            show_name=res['show_name']
        
        if 'code' in vals.keys():
            code=vals['code']
        if 'show_name' in vals.keys():
            show_name=vals['show_name']
        vals['name']=code+' '+show_name
        return super(Accounts, self).write(cr, uid, ids, vals, context=context)
    
    def create(self, cr, uid, vals, context=None):
        vals['name']=vals['code']+' '+vals['show_name']
        return super(Accounts, self).create(cr, uid, vals, context=context)
    
    def onchange_parent_id(self,cr,uid,ids,parent_id,code,context=None):
        pass
    
        
Accounts()